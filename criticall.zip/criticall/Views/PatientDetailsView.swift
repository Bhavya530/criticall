import SwiftUI
import Charts

struct PatientDetailsView: View {
    @Environment(\.dismiss) var dismiss
    var patient: PatientModel?
    @State private var testResults: [LabLatestModel] = []
    @State private var labHistory: [LabHistoryModel] = []
    @State private var isLoading = true
    @State private var errorMessage: String? = nil
    @State private var selectedTab = "Current"
    @State private var selectedParameter: String = ""
    @State private var isDischarging = false
    @State private var showDischargedAlert = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                }
                
                Text("Patient Record")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.leading, 15)
                
                Spacer()
                
                Button(action: { dischargePatient() }) {
                    if isDischarging {
                        ProgressView().tint(.white)
                    } else {
                        Text("Discharge")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.red)
                    }
                }
            }
            .padding(20)
            .background(Color.black)

            // Tab Switcher
            HStack {
                ForEach(["Current", "Trends", "History"], id: \.self) { tab in
                    Button(tab) { selectedTab = tab }
                        .frame(maxWidth: .infinity)
                        .foregroundColor(selectedTab == tab ? .teal : .gray)
                        .bold(selectedTab == tab)
                }
            }
            .padding()

            ScrollView {
                if selectedTab == "Current" {
                    VStack(alignment: .leading, spacing: 15) {
                        Text(patient?.full_name ?? "Patient").font(.title).bold()
                        Text("ID: \(patient?.patient_id ?? "N/A")")
                        
                        Divider()
                        
                        if isLoading {
                            ProgressView()
                        } else if testResults.isEmpty {
                            Text("No records yet").foregroundColor(.gray)
                        } else {
                            ForEach(testResults) { result in
                                ResultCard(result: result)
                            }
                        }
                    }
                    .padding()
                } else if selectedTab == "Trends" {
                    if labHistory.count < 2 {
                        Text("No records yet (Need 2+ tests for trends)").padding()
                    } else {
                        TrendsView(history: labHistory, selectedParameter: $selectedParameter)
                    }
                } else {
                    VStack(spacing: 12) {
                        ForEach(labHistory) { record in
                            HistoryRow(record: record)
                        }
                    }
                    .padding()
                }
            }
        }
        .background(Color.black.ignoresSafeArea())
        .foregroundColor(.white)
        .onAppear { fetchData() }
        .alert("Discharged", isPresented: $showDischargedAlert) {
            Button("OK") { dismiss() }
        }
    }
    
    private func fetchData() {
        guard let pid = patient?.patient_id else { return }
        isLoading = true
        APIManager.shared.fetchLabLatest(for: pid) { results, _ in
            self.testResults = results ?? []
        }
        APIManager.shared.fetchLabHistory(for: pid) { history, _ in
            self.labHistory = history ?? []
            if let first = history?.first?.payload?.keys.first {
                self.selectedParameter = first
            }
            self.isLoading = false
        }
    }
    
    private func dischargePatient() {
        guard let pid = patient?.patient_id, let did = APIManager.shared.currentUser?.userId else { return }
        isDischarging = true
        APIManager.shared.updatePatientStatus(doctorId: did, patientId: pid, status: "Stable", discharged: true) { success, _ in
            isDischarging = false
            if success { showDischargedAlert = true }
        }
    }
}

struct ResultCard: View {
    let result: LabLatestModel
    var body: some View {
        VStack(alignment: .leading) {
            Text(result.category).font(.headline).foregroundColor(.teal)
            if let payload = result.payload {
                ForEach(Array(payload.keys.sorted()), id: \.self) { key in
                    HStack {
                        Text(key)
                        Spacer()
                        Text("\(String(describing: payload[key]!.value))").bold()
                    }
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.1))
        .cornerRadius(10)
    }
}

struct HistoryRow: View {
    let record: LabHistoryModel
    var body: some View {
        HStack {
            Text(record.category).bold()
            Spacer()
            Text("\(record.timestamp_ms)") // formatDate would be better
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(8)
    }
}

struct TrendsView: View {
    let history: [LabHistoryModel]
    @Binding var selectedParameter: String
    
    var chartData: [ChartDataPoint] {
        history.compactMap { record -> ChartDataPoint? in
            guard let valObj = record.payload?[selectedParameter],
                  let val = Double(String(describing: valObj.value)) else { return nil }
            return ChartDataPoint(date: Date(timeIntervalSince1970: TimeInterval(record.timestamp_ms)/1000), value: val)
        }.sorted { $0.date < $1.date }
    }
    
    var body: some View {
        VStack {
            Picker("Parameter", selection: $selectedParameter) {
                ForEach(history.first?.payload?.keys.sorted() ?? [], id: \.self) { key in
                    Text(key).tag(key)
                }
            }
            Chart(chartData) { point in
                LineMark(x: .value("Date", point.date), y: .value("Value", point.value))
                PointMark(x: .value("Date", point.date), y: .value("Value", point.value))
            }
            .frame(height: 250)
            .padding()
        }
    }
}

struct ChartDataPoint: Identifiable {
    let id = UUID()
    let date: Date
    let value: Double
}

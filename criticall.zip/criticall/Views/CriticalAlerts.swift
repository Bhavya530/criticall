import SwiftUI
import UIKit
struct AlertListCard: View {
    let alert: CriticalNotificationModel
    var onRecommendMedication: (() -> Void)? = nil
    var onResolve: (() -> Void)? = nil
    var body: some View {
        let isActive = (alert.is_resolved == 0)
        
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Circle()
                    .fill(isActive ? Color.red : Color.gray)
                    .frame(width: 12, height: 12)
                Text(alert.patient_name ?? "Unknown Patient")
                    .foregroundColor(isActive ? .white : .gray)
                    .bold()
                Text("(\(alert.patient_id))")
                    .foregroundColor(.gray)
                Spacer()
            }
            Text(alert.payload?.alertType ?? "Critical Parameter")
                .foregroundColor(.gray)
            HStack {
                Text(alert.payload?.value ?? "-")
                    .font(.title2)
                    .foregroundColor(isActive ? .red : .gray)
                    .bold()
                Spacer()
                Text("Normal: \(alert.payload?.normalRange ?? "-")")
                    .foregroundColor(.gray)
                    .font(.subheadline)
            }
            HStack {
                Image(systemName: "clock")
                    .foregroundColor(.gray)
                    .font(.caption)
                // In reality you would format the date beautifully "2 mins ago" from `alert.created_at`
                Text(alert.created_at ?? "Recently")
                    .foregroundColor(.gray)
                    .font(.caption)
                Spacer()
            }

            HStack(spacing: 12) {
                Button(action: {
                    onRecommendMedication?()
                }) {
                    HStack {
                        Image(systemName: "pills.fill")
                        Text("Recommend Medication")
                    }
                    .font(.system(size: 14, weight: .semibold))
                    .padding(.vertical, 8)
                    .padding(.horizontal)
                    .foregroundColor(isActive ? Color.white : Color.gray)
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(8)
                }
                if isActive {
                    Button(action: {
                        onResolve?()
                    }) {
                        HStack {
                            Image(systemName: "checkmark.circle")
                            Text("Mark Resolved")
                        }
                        .padding(.vertical, 8)
                        .padding(.horizontal)
                        .foregroundColor(.white)
                        .background(Color.green)
                        .cornerRadius(8)
                    }
                } else {
                    HStack {
                        Image(systemName: "checkmark.circle")
                        Text("Resolved")
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal)
                    .foregroundColor(.green)
                    .background(Color.gray.opacity(0.3))
                    .cornerRadius(8)
                }
            }
        }
        .padding()
        .background(isActive ? Color(red: 30/255, green: 35/255, blue: 40/255) : Color(red: 20/255, green: 20/255, blue: 23/255))
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.3), radius: 4, x: 0, y: 2)
    }
}

struct CriticalAlertsView: View {
    @StateObject private var viewModel = CriticalAlertsViewModel()
    @State private var selectedTab = "Critical Alerts"
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var selectedAlert: CriticalNotificationModel?
    
    var body: some View {
        VStack(spacing: 0) {
            // HEADER
            HStack {
                Text("Critical Alerts")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("\(viewModel.activeCount) Active")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(20)
            }
            .padding(.horizontal)
            .padding(.top, 20)
            
            // SELECTOR TABS
            HStack(spacing: 12) {
                Button(action: { selectedTab = "Critical Alerts" }) {
                    Text("Critical Alerts")
                        .font(.system(size: 16, weight: .medium))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(selectedTab == "Critical Alerts" ? Color.gray.opacity(0.3) : Color.clear)
                        .foregroundColor(selectedTab == "Critical Alerts" ? .white : .gray)
                        .cornerRadius(20)
                }
                
                Button(action: { selectedTab = "Predicted Risk" }) {
                    Text("Predicted Risk")
                        .font(.system(size: 16, weight: .medium))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(selectedTab == "Predicted Risk" ? Color.gray.opacity(0.3) : Color.clear)
                        .foregroundColor(selectedTab == "Predicted Risk" ? .white : .gray)
                        .cornerRadius(20)
                }
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 25)
            
            // CONTENT
            ScrollView {
                VStack(spacing: 16) {
                    if viewModel.isLoading {
                        ProgressView()
                            .padding(.top, 40)
                    } else if selectedTab == "Critical Alerts" {
                        ForEach(viewModel.activeAlerts) { alert in
                            AlertListCard(alert: alert, onRecommendMedication: {
                                selectedAlert = alert
                            }) {
                                viewModel.resolveAlert(notificationId: alert.notification_id)
                                toastMessage = "Alert archived and removed for\n\(alert.patient_name ?? "Unknown")"
                                withAnimation { showToast = true }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    withAnimation { showToast = false }
                                }
                            }
                            .padding(.horizontal)
                        }
                        if viewModel.activeAlerts.isEmpty {
                            VStack(spacing: 20) {
                                Image(systemName: "bell.slash")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 80, height: 80)
                                    .foregroundColor(.gray.opacity(0.5))
                                    .padding(.top, 50)
                                
                                Text("No Alerts Found")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.gray)
                            }
                        }
                    } else {
                        // Predicted Risk Empty State
                        VStack(spacing: 20) {
                            Image(systemName: "clock.badge.exclamationmark")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                                .foregroundColor(.gray.opacity(0.5))
                                .padding(.top, 50)
                            
                            Text("No Predicted Risks")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.gray)
                        }
                    }
                }
                .padding(.top, 10)
            }
            
            // NAVIGATION TAB BAR
            HStack {
                TabBarItem(icon: "house", label: "Home", active: false)
                Spacer()
                TabBarItem(icon: "person.2", label: "Patients", active: false)
                Spacer()
                TabBarItem(icon: "exclamationmark.triangle", label: "Alerts", active: true)
                    .padding(10)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(12)
                Spacer()
                TabBarItem(icon: "person", label: "Profile", active: false)
            }
            .padding(.horizontal, 30)
            .padding(.bottom, 10)
            .frame(height: 80)
            .background(Color.black)
        }
        .background(Color.black.ignoresSafeArea())
        .overlay(
            VStack {
                Spacer()
                if showToast {
                    HStack(spacing: 12) {
                        Image("ic_criticall_notification")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .background(Color.white)
                            .clipShape(Circle())
                            
                        Text(toastMessage)
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Color(red: 0.85, green: 0.85, blue: 0.85)) // Light gray background
                    .cornerRadius(25)
                    .padding(.bottom, 100) // Above tab bar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        )
        .sheet(item: $selectedAlert) { alert in
            RecommendMedicationSheet(alert: alert) {
                selectedAlert = nil
            }
            .presentationDetents([.medium, .large])
        }
        .onAppear {
            viewModel.fetchAlerts()
        }
    }
}

// If your Xcode doesn't support the #Preview macro, use instead:
// struct CriticalAlertsView_Previews: PreviewProvider {
//     static var previews: some View {
//         CriticalAlertsView()
//     }
// }

//
//  CriticalAlerts.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//

struct RecommendMedicationSheet: View {
    let alert: CriticalNotificationModel
    let onClose: () -> Void

    @State private var medicationText: String = ""
    @FocusState private var isEditorFocused: Bool
    @State private var isSending = false

    private let sheetBg  = Color(red: 17/255, green: 19/255, blue: 22/255)
    private let editorBg = Color(red: 22/255, green: 25/255, blue: 30/255)
    private let cardBg   = Color(red: 35/255, green: 40/255, blue: 45/255)
    private let placeholder = "Write medicine names here...\n\ne.g.\n• Amoxicillin 500mg — PO BID\n• Paracetamol 650mg — PO TDS\n• IV Fluids 0.9% NaCl @ 100ml/hr"

    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            Capsule()
                .fill(Color.gray.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, 12)
                .padding(.bottom, 20)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {

                    // HEADER SECTION
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(LinearGradient(
                                    gradient: Gradient(colors: [Color.teal, Color.blue]),
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ))
                                .frame(width: 50, height: 50)
                                .shadow(color: Color.teal.opacity(0.5), radius: 8, x: 0, y: 4)
                            Image(systemName: "pills.fill")
                                .foregroundColor(.white)
                                .font(.title2)
                        }

                        VStack(alignment: .leading, spacing: 4) {
                            Text("e-Prescribe")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(.white)
                            Text("Recommend Medication")
                                .font(.subheadline)
                                .foregroundColor(.teal)
                        }
                        Spacer()
                    }

                    // PATIENT INFO CARD
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "person.text.rectangle")
                                .foregroundColor(.gray)
                            Text("Patient Profile")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .foregroundColor(.gray)
                        }
                        HStack {
                            Text(alert.patient_name ?? "Unknown Patient")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            Spacer()
                            Text("ID: \(alert.patient_id)")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.black.opacity(0.4))
                                .cornerRadius(6)
                        }
                        HStack {
                            Text("Critical Issue:")
                                .foregroundColor(.red)
                                .font(.caption)
                                .fontWeight(.bold)
                            Text("\(alert.payload?.alertType?.replacingOccurrences(of: "Critical ", with: "") ?? "Parameter") (\(alert.payload?.value ?? "?"))")
                                .foregroundColor(.white)
                                .font(.caption)
                        }
                    }
                    .padding()
                    .background(Color(red: 35/255, green: 40/255, blue: 45/255))
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.05), lineWidth: 1)
                    )

                    // TEXT EDITOR SECTION
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "pencil.and.list.clipboard")
                                .foregroundColor(.teal)
                                .font(.system(size: 14))
                            Text("MEDICATION NOTES")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(.gray)
                            Spacer()
                            Text("\(medicationText.count) chars")
                                .font(.system(size: 11))
                                .foregroundColor(medicationText.isEmpty ? .gray.opacity(0.4) : .teal.opacity(0.8))
                        }

                        ZStack(alignment: .topLeading) {
                            // Editor background + border
                            RoundedRectangle(cornerRadius: 16)
                                .fill(editorBg)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(
                                            isEditorFocused ? Color.teal.opacity(0.6) : Color.white.opacity(0.07),
                                            lineWidth: 1.5
                                        )
                                )

                            // Placeholder (rendered behind editor when empty)
                            if medicationText.isEmpty {
                                Text(placeholder)
                                    .font(.system(size: 15))
                                    .foregroundColor(Color.white.opacity(0.25))
                                    .padding(.horizontal, 20)
                                    .padding(.top, 18)
                                    .allowsHitTesting(false)
                            }

                            // TextEditor — explicit dark background, no system background override
                            TextEditor(text: $medicationText)
                                .focused($isEditorFocused)
                                .font(.system(size: 15))
                                .foregroundColor(.white)
                                .scrollContentBackground(.hidden)
                                .background(editorBg)
                                .padding(8)
                                .frame(minHeight: 260)
                                .opacity(medicationText.isEmpty && !isEditorFocused ? 0.01 : 1)
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .animation(.easeInOut(duration: 0.2), value: isEditorFocused)
                        .onTapGesture { isEditorFocused = true }

                        // Quick-add chip row
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(["Paracetamol", "Amoxicillin", "Metformin", "Aspirin", "Ibuprofen", "Omeprazole"], id: \.self) { med in
                                    Button(action: {
                                        let line = medicationText.isEmpty ? "• \(med)" : "\n• \(med)"
                                        medicationText += line
                                    }) {
                                        HStack(spacing: 4) {
                                            Image(systemName: "plus.circle.fill")
                                                .font(.system(size: 11))
                                            Text(med)
                                                .font(.system(size: 13, weight: .medium))
                                        }
                                        .foregroundColor(.teal)
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 7)
                                        .background(Color.teal.opacity(0.12))
                                        .cornerRadius(20)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 20)
                                                .stroke(Color.teal.opacity(0.3), lineWidth: 1)
                                        )
                                    }
                                }
                            }
                            .padding(.vertical, 2)
                        }
                    }
                    .padding(.top, 4)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }

            // BOTTOM ACTION BAR
            VStack(spacing: 0) {
                Divider().background(Color.white.opacity(0.1))
                HStack(spacing: 16) {
                    Button(action: { onClose() }) {
                        Text("Cancel")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                    }

                    Button(action: {
                        isSending = true
                        let doctorId = APIManager.shared.currentUser?.userId ?? "UNKNOWN"
                        APIManager.shared.postPatientMedication(patientId: alert.patient_id, doctorId: doctorId, medicationText: medicationText) { success, error in
                            DispatchQueue.main.async {
                                isSending = false
                                onClose()
                            }
                        }
                    }) {
                        HStack(spacing: 8) {
                            if isSending {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Image(systemName: "icloud.and.arrow.up.fill")
                                Text("Upload")
                            }
                        }
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            medicationText.isEmpty
                                ? AnyShapeStyle(Color.gray.opacity(0.3))
                                : AnyShapeStyle(LinearGradient(
                                    gradient: Gradient(colors: [Color.teal, Color.blue]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ))
                        )
                        .cornerRadius(16)
                        .shadow(color: medicationText.isEmpty ? .clear : Color.teal.opacity(0.4), radius: 6, x: 0, y: 4)
                    }
                    .disabled(medicationText.isEmpty || isSending)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
            }
            .background(Color(red: 20/255, green: 22/255, blue: 26/255).edgesIgnoringSafeArea(.bottom))
        }
        .background(sheetBg.edgesIgnoringSafeArea(.all))
        .preferredColorScheme(.dark)
    }
}


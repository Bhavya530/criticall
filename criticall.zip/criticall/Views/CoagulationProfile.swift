import SwiftUI

struct CoagulationProfileView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedTests: [String] = []
    var patient: PatientModel?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    Text("Coagulation")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 15)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.black)

                ScrollView {
                    VStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Select tests to perform")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal)

                        Text("Available Tests")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal)

                        VStack(spacing: 16) {
                            // PT
                            TestCategoryRow(
                                title: "PT",
                                subtitle: "Prothrombin time",
                                tags: ["PT"],
                                isSelected: selectedTests.contains("PT")
                            ) {
                                toggleSelection(for: "PT")
                            }

                            // INR
                            TestCategoryRow(
                                title: "INR",
                                subtitle: "International normalized ratio",
                                tags: ["INR"],
                                isSelected: selectedTests.contains("INR")
                            ) {
                                toggleSelection(for: "INR")
                            }

                            // APTT
                            TestCategoryRow(
                                title: "APTT",
                                subtitle: "Activated partial thromboplastin time",
                                tags: ["APTT"],
                                isSelected: selectedTests.contains("APTT")
                            ) {
                                toggleSelection(for: "APTT")
                            }
                        }
                        .padding(.horizontal)

                        // Alert Section
                        CommonAlertView()
                            .padding(.top, 10)
                    }
                    .padding(.bottom, 120)
                }
            }
            
            if !selectedTests.isEmpty {
                VStack {
                    Spacer()
                    NavigationLink(destination: LabParameterEntryView(patient: patient, selectedTests: selectedTests)) {
                        Text("PROCEED TO TEST ENTRY")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(Color(red: 0.6, green: 0.4, blue: 0.8)) // Purple
                            .cornerRadius(12)
                            .padding()
                    }
                    .background(
                        LinearGradient(gradient: Gradient(colors: [.black.opacity(0), .black]), startPoint: .top, endPoint: .bottom)
                            .padding(.top, -20)
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }

    private func toggleSelection(for test: String) {
        if selectedTests.contains(test) {
            selectedTests.removeAll(where: { $0 == test })
        } else {
            selectedTests.append(test)
        }
    }
}

#Preview {
    CoagulationProfileView()
}

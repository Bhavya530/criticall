<?php

declare(strict_types=1);

use Criticall\Auth;
use Criticall\Database;
use Criticall\Response;
use Criticall\SmtpMailer;

require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/Response.php';
require_once __DIR__ . '/../src/Auth.php';
require_once __DIR__ . '/../src/SmtpMailer.php';

if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$k, $v] = explode('=', $line, 2);
        $k = trim($k);
        $v = trim($v);
        putenv($k . '=' . $v);
        $_ENV[$k] = $v;
        $_SERVER[$k] = $v;
    }
}

$config = require __DIR__ . '/../src/config.php';
$db = new Database($config['db']);
$pdo = $db->pdo();
$auth = new Auth($pdo);

function jsonBody(): array
{
    $raw = file_get_contents('php://input');
    if (!$raw) {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function segments(): array
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    return array_values(array_filter(explode('/', trim($path, '/'))));
}

function routeParts(): array
{
    $parts = segments();
    $apiIndex = array_search('api', $parts, true);
    if ($apiIndex === false) {
        return $parts;
    }
    return array_slice($parts, (int)$apiIndex);
}

function userPublic(array $row): array
{
    return [
        'userId' => $row['user_id'],
        'name' => $row['name'],
        'role' => $row['role'],
        'department' => $row['department'],
        'email' => $row['email'],
        'phone' => $row['phone'],
        'location' => $row['location'],
        'shift' => $row['shift'],
        'supervisor' => $row['supervisor'],
        'profileImage' => $row['profile_image'],
        'notification_preferences' => $row['notification_preferences'] ? json_decode($row['notification_preferences'], true) : null,
    ];
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$parts = routeParts();

if (count($parts) >= 1 && ($parts[0] === 'health' || (count($parts) >= 2 && $parts[1] === 'health'))) {
    Response::json(['ok' => true, 'service' => 'criticall-php-backend']);
    exit;
}

if (count($parts) < 2 || $parts[0] !== 'api') {
    Response::json(['error' => 'Not Found'], 404);
    exit;
}

$resource = $parts[1];
$body = jsonBody();

try {
    if ($resource === 'auth' && ($parts[2] ?? '') === 'login' && $method === 'POST') {
        $userId = strtoupper(trim((string)($body['userId'] ?? '')));
        $password = (string)($body['password'] ?? '');

        $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id=:uid LIMIT 1');
        $stmt->execute(['uid' => $userId]);
        $user = $stmt->fetch();

        if (!$user) {
            Response::json(['error' => 'User not found'], 404);
            exit;
        }

        if (!password_verify($password, $user['password_hash'])) {
            Response::json(['error' => 'Invalid credentials'], 401);
            exit;
        }

        $token = $auth->createTokenForUserId($userId);
        Response::json(['token' => $token, 'user' => userPublic($user)]);
        exit;
    }

    if ($resource === 'auth' && ($parts[2] ?? '') === 'signup-labtech' && $method === 'POST') {
        $userId = strtoupper(trim((string)($body['userId'] ?? '')));
        $name = trim((string)($body['name'] ?? ''));
        $password = (string)($body['password'] ?? '');
        $email = trim((string)($body['email'] ?? ''));
        $phone = trim((string)($body['phone'] ?? ''));
        $department = trim((string)($body['department'] ?? ''));

        if ($userId === '' || $name === '' || $password === '' || $email === '') {
            Response::json(['error' => 'Missing fields'], 422);
            exit;
        }

        $exists = $pdo->prepare('SELECT 1 FROM users WHERE user_id=:uid LIMIT 1');
        $exists->execute(['uid' => $userId]);
        if ($exists->fetch()) {
            Response::json(['error' => 'User ID already exists'], 409);
            exit;
        }

        $insert = $pdo->prepare('INSERT INTO users (user_id,password_hash,name,role,department,email,phone,shift,supervisor,profile_image) VALUES (:uid,:ph,:name,:role,:department,:email,:phone,:shift,:supervisor,:profile_image)');
        $insert->execute([
            'uid' => $userId,
            'ph' => password_hash($password, PASSWORD_DEFAULT),
            'name' => $name,
            'role' => 'LabTechnician',
            'department' => $department,
            'email' => $email,
            'phone' => $phone,
            'shift' => $body['shift'] ?? 'Day Shift (7AM - 3PM)',
            'supervisor' => $body['supervisor'] ?? 'Dr. Patricia Johnson',
            'profile_image' => $body['profileImage'] ?? 'ic_labtech_profile',
        ]);

        Response::json(['ok' => true], 201);
        exit;
    }

    if ($resource === 'auth' && ($parts[2] ?? '') === 'forgot-password' && $method === 'POST') {
        $email = strtolower(trim((string)($body['email'] ?? '')));
        if ($email === '') {
            Response::json(['error' => 'Email is required'], 422);
            exit;
        }

        $stmt = $pdo->prepare('SELECT id,user_id,name,email FROM users WHERE LOWER(email)=:email LIMIT 1');
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();
        if (!$user) {
            Response::json(['ok' => true]);
            exit;
        }

        $otp = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$token = 'OTP-' . $otp . '-' . bin2hex(random_bytes(4));
$expiresAt = date('Y-m-d H:i:s', time() + (int)(getenv('RESET_TOKEN_TTL_SECONDS') ?: 3600));
$ins = $pdo->prepare('INSERT INTO password_reset_tokens (user_id,email,token,expires_at,used) VALUES (:uid,:email,:token,:expires,0)');
$ins->execute([
    'uid' => (int)$user['id'],
    'email' => $user['email'],
    'token' => $token,
    'expires' => $expiresAt,
]);

$subject = 'Criticall Password Reset OTP';
$message = "Hello " . ($user['name'] ?: $user['user_id']) . ",\n\n"
    . "Use this OTP code to reset your password:\n"
    . $otp . "\n\n"
    . "OTP expires at: " . $expiresAt . "\n"
    . "Do not share this code with anyone.\n";

        $mailer = new SmtpMailer([
            'host' => getenv('SMTP_HOST') ?: '',
            'port' => (int)(getenv('SMTP_PORT') ?: 587),
            'username' => getenv('SMTP_USERNAME') ?: '',
            'password' => getenv('SMTP_PASSWORD') ?: '',
            'encryption' => getenv('SMTP_ENCRYPTION') ?: 'tls',
            'timeout' => (int)(getenv('SMTP_TIMEOUT') ?: 15),
        ]);
        $from = (string)(getenv('SMTP_FROM') ?: 'no-reply@saveetha.com');

        $mailer->send($from, $user['email'], $subject, $message);
        Response::json(['ok' => true]);
        exit;
    }

    if ($resource === 'users' && count($parts) >= 4) {
        $roleSegment = $parts[2];
        $userId = strtoupper($parts[3]);
        $role = $roleSegment === 'doctors' ? 'Doctor' : ($roleSegment === 'labtechs' ? 'LabTechnician' : null);
        if (!$role) {
            Response::json(['error' => 'Invalid role path'], 404);
            exit;
        }

        if ($method === 'GET' && count($parts) === 4) {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id=:uid AND role=:role LIMIT 1');
            $stmt->execute(['uid' => $userId, 'role' => $role]);
            $user = $stmt->fetch();
            if (!$user) {
                Response::json(['error' => 'User not found'], 404);
                exit;
            }
            Response::json(['user' => userPublic($user)]);
            exit;
        }

        if ($method === 'PUT' && count($parts) === 4) {
            $stmt = $pdo->prepare('UPDATE users SET name=:name, department=:department, email=:email, phone=:phone, location=:location, shift=:shift, supervisor=:supervisor, profile_image=:profile_image WHERE user_id=:uid AND role=:role');
            $stmt->execute([
                'name' => $body['name'] ?? null,
                'department' => $body['department'] ?? null,
                'email' => $body['email'] ?? null,
                'phone' => $body['phone'] ?? null,
                'location' => $body['location'] ?? null,
                'shift' => $body['shift'] ?? null,
                'supervisor' => $body['supervisor'] ?? null,
                'profile_image' => $body['profileImage'] ?? null,
                'uid' => $userId,
                'role' => $role,
            ]);
            Response::json(['ok' => true]);
            exit;
        }

        if ($method === 'POST' && count($parts) === 5 && $parts[4] === 'change-password') {
            $current = (string)($body['currentPassword'] ?? '');
            $next = (string)($body['newPassword'] ?? '');
            $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE user_id=:uid AND role=:role LIMIT 1');
            $stmt->execute(['uid' => $userId, 'role' => $role]);
            $user = $stmt->fetch();
            if (!$user || !password_verify($current, $user['password_hash'])) {
                Response::json(['error' => 'Current password invalid'], 401);
                exit;
            }
            $up = $pdo->prepare('UPDATE users SET password_hash=:ph WHERE user_id=:uid AND role=:role');
            $up->execute(['ph' => password_hash($next, PASSWORD_DEFAULT), 'uid' => $userId, 'role' => $role]);
            Response::json(['ok' => true]);
            exit;
        }

        if ($method === 'POST' && count($parts) === 5 && $parts[4] === 'notification-preferences') {
            $pref = json_encode([
                'email' => (bool)($body['email'] ?? false),
                'push' => (bool)($body['push'] ?? true),
                'sms' => (bool)($body['sms'] ?? false),
            ], JSON_UNESCAPED_UNICODE);
            $up = $pdo->prepare('UPDATE users SET notification_preferences=:pref WHERE user_id=:uid AND role=:role');
            $up->execute(['pref' => $pref, 'uid' => $userId, 'role' => $role]);
            Response::json(['ok' => true]);
            exit;
        }
    }

    if ($resource === 'patients' && count($parts) >= 3) {
        $doctorId = strtoupper($parts[2]);

        if ($method === 'GET' && count($parts) === 3) {
            $stmt = $pdo->prepare('SELECT patient_id,full_name,age,gender,contact_number,ward_room,diagnosis,tests_ordered,photo_url,status,discharged,doctor_user_id FROM patients WHERE doctor_user_id=:did ORDER BY updated_at DESC');
            $stmt->execute(['did' => $doctorId]);
            Response::json(['patients' => $stmt->fetchAll()]);
            exit;
        }

        if ($method === 'POST' && count($parts) === 3) {
            $stmt = $pdo->prepare('INSERT INTO patients (patient_id,doctor_user_id,full_name,age,gender,contact_number,ward_room,diagnosis,tests_ordered,photo_url,status,discharged) VALUES (:patient_id,:doctor_user_id,:full_name,:age,:gender,:contact_number,:ward_room,:diagnosis,:tests_ordered,:photo_url,:status,:discharged) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name), age=VALUES(age), gender=VALUES(gender), contact_number=VALUES(contact_number), ward_room=VALUES(ward_room), diagnosis=VALUES(diagnosis), tests_ordered=VALUES(tests_ordered), photo_url=VALUES(photo_url), status=VALUES(status), discharged=VALUES(discharged)');
            $stmt->execute([
                'patient_id' => (string)$body['patientId'],
                'doctor_user_id' => $doctorId,
                'full_name' => (string)$body['fullName'],
                'age' => (int)$body['age'],
                'gender' => (string)$body['gender'],
                'contact_number' => $body['contactNumber'] ?? null,
                'ward_room' => $body['wardRoom'] ?? null,
                'diagnosis' => $body['diagnosis'] ?? null,
                'tests_ordered' => $body['testsOrdered'] ?? null,
                'photo_url' => $body['photoUrl'] ?? null,
                'status' => $body['status'] ?? 'Active',
                'discharged' => isset($body['discharged']) ? (int)((bool)$body['discharged']) : 0,
            ]);
            Response::json(['ok' => true], 201);
            exit;
        }

        if (count($parts) === 4) {
            $patientId = $parts[3];
            if ($method === 'GET') {
                $stmt = $pdo->prepare('SELECT patient_id,full_name,age,gender,contact_number,ward_room,diagnosis,tests_ordered,photo_url,status,discharged,doctor_user_id FROM patients WHERE doctor_user_id=:did AND patient_id=:pid LIMIT 1');
                $stmt->execute(['did' => $doctorId, 'pid' => $patientId]);
                $p = $stmt->fetch();
                if (!$p) {
                    Response::json(['error' => 'Patient not found'], 404);
                    exit;
                }
                Response::json(['patient' => $p]);
                exit;
            }
            if ($method === 'PUT') {
                $stmt = $pdo->prepare('UPDATE patients SET full_name=:full_name, age=:age, gender=:gender, contact_number=:contact_number, ward_room=:ward_room, diagnosis=:diagnosis, tests_ordered=:tests_ordered, photo_url=:photo_url, status=:status, discharged=:discharged WHERE doctor_user_id=:did AND patient_id=:pid');
                $stmt->execute([
                    'full_name' => $body['fullName'] ?? null,
                    'age' => isset($body['age']) ? (int)$body['age'] : null,
                    'gender' => $body['gender'] ?? null,
                    'contact_number' => $body['contactNumber'] ?? null,
                    'ward_room' => $body['wardRoom'] ?? null,
                    'diagnosis' => $body['diagnosis'] ?? null,
                    'tests_ordered' => $body['testsOrdered'] ?? null,
                    'photo_url' => $body['photoUrl'] ?? null,
                    'status' => $body['status'] ?? 'Active',
                    'discharged' => isset($body['discharged']) ? (int)((bool)$body['discharged']) : 0,
                    'did' => $doctorId,
                    'pid' => $patientId,
                ]);
                Response::json(['ok' => true]);
                exit;
            }
        }
    }

    if ($resource === 'patients' && $method === 'GET' && count($parts) === 2) {
        $stmt = $pdo->prepare('SELECT patient_id,full_name,age,gender,contact_number,ward_room,diagnosis,tests_ordered,photo_url,status,discharged,doctor_user_id FROM patients ORDER BY updated_at DESC');
        $stmt->execute();
        Response::json(['patients' => $stmt->fetchAll()]);
        exit;
    }

    if ($resource === 'patients' && $method === 'POST' && count($parts) === 5 && $parts[4] === 'status') {
        $doctorId = strtoupper($parts[2]);
        $patientId = $parts[3];
        $stmt = $pdo->prepare('UPDATE patients SET status=:status, discharged=:discharged WHERE doctor_user_id=:did AND patient_id=:pid');
        $stmt->execute([
            'status' => $body['status'] ?? 'Active',
            'discharged' => isset($body['discharged']) ? (int)((bool)$body['discharged']) : 0,
            'did' => $doctorId,
            'pid' => $patientId,
        ]);
        Response::json(['ok' => true]);
        exit;
    }

    if ($resource === 'critical-notifications' && count($parts) >= 3) {
        $doctorId = strtoupper($parts[2]);

        if ($method === 'GET' && count($parts) === 3) {
            $stmt = $pdo->prepare('SELECT notification_id,patient_id,patient_name,payload,is_resolved,created_at,updated_at FROM critical_notifications WHERE doctor_user_id=:did ORDER BY updated_at DESC');
            $stmt->execute(['did' => $doctorId]);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['payload'] = json_decode($r['payload'], true);
            }
            Response::json(['notifications' => $rows]);
            exit;
        }

        if ($method === 'POST' && count($parts) === 3) {
            $nid = (string)($body['notificationId'] ?? '');
            $stmt = $pdo->prepare('INSERT INTO critical_notifications (notification_id,doctor_user_id,patient_id,patient_name,payload,is_resolved) VALUES (:nid,:did,:pid,:pname,:payload,0) ON DUPLICATE KEY UPDATE payload=VALUES(payload), patient_name=VALUES(patient_name), is_resolved=0');
            $stmt->execute([
                'nid' => $nid,
                'did' => $doctorId,
                'pid' => (string)$body['patientId'],
                'pname' => $body['patientName'] ?? null,
                'payload' => json_encode($body['payload'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
            Response::json(['ok' => true], 201);
            exit;
        }

        if ($method === 'PUT' && count($parts) === 5 && $parts[4] === 'resolve') {
            $nid = $parts[3];
            $stmt = $pdo->prepare('UPDATE critical_notifications SET is_resolved=1 WHERE doctor_user_id=:did AND notification_id=:nid');
            $stmt->execute(['did' => $doctorId, 'nid' => $nid]);
            Response::json(['ok' => true]);
            exit;
        }
    }

    if ($resource === 'predicted-alerts' && count($parts) >= 3) {
        $doctorId = strtoupper($parts[2]);
        if ($method === 'GET' && count($parts) === 3) {
            $stmt = $pdo->prepare('SELECT patient_id,payload FROM predicted_alerts WHERE doctor_user_id=:did ORDER BY updated_at DESC');
            $stmt->execute(['did' => $doctorId]);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['payload'] = json_decode($r['payload'], true);
            }
            Response::json(['alerts' => $rows]);
            exit;
        }

        if ($method === 'PUT' && count($parts) === 4) {
            $patientId = $parts[3];
            $stmt = $pdo->prepare('INSERT INTO predicted_alerts (doctor_user_id,patient_id,payload) VALUES (:did,:pid,:payload) ON DUPLICATE KEY UPDATE payload=VALUES(payload)');
            $stmt->execute([
                'did' => $doctorId,
                'pid' => $patientId,
                'payload' => json_encode($body['payload'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
            Response::json(['ok' => true]);
            exit;
        }
    }

    if ($resource === 'test-results' && $method === 'POST') {
        $stmt = $pdo->prepare('INSERT INTO test_results (doctor_user_id,patient_id,lab_user_id,category,payload) VALUES (:did,:pid,:lid,:category,:payload)');
        $stmt->execute([
            'did' => strtoupper((string)$body['doctorId']),
            'pid' => (string)$body['patientId'],
            'lid' => strtoupper((string)$body['labUserId']),
            'category' => (string)$body['category'],
            'payload' => json_encode($body['payload'] ?? [], JSON_UNESCAPED_UNICODE),
        ]);
        Response::json(['ok' => true], 201);
        exit;
    }

    if ($resource === 'lab-history') {
        if ($method === 'POST') {
            $patientId = (string)($body['patientId'] ?? '');
            $doctorId = strtoupper((string)($body['doctorId'] ?? ''));
            $labUserId = strtoupper((string)($body['labUserId'] ?? ''));
            $category = (string)($body['category'] ?? '');
            $timestampMs = (int)($body['timestampMs'] ?? round(microtime(true) * 1000));
            $payload = $body['payload'] ?? [];

            if ($patientId === '' || $doctorId === '' || $labUserId === '' || $category === '') {
                Response::json(['error' => 'Missing fields'], 422);
                exit;
            }

            $ins = $pdo->prepare('INSERT INTO lab_history (patient_id,doctor_user_id,lab_user_id,category,timestamp_ms,payload) VALUES (:pid,:did,:lid,:category,:ts,:payload)');
            $ins->execute([
                'pid' => $patientId,
                'did' => $doctorId,
                'lid' => $labUserId,
                'category' => $category,
                'ts' => $timestampMs,
                'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE),
            ]);

            $up = $pdo->prepare('INSERT INTO lab_latest (patient_id,category,doctor_user_id,lab_user_id,timestamp_ms,payload) VALUES (:pid,:category,:did,:lid,:ts,:payload) ON DUPLICATE KEY UPDATE doctor_user_id=VALUES(doctor_user_id), lab_user_id=VALUES(lab_user_id), timestamp_ms=VALUES(timestamp_ms), payload=VALUES(payload)');
            $up->execute([
                'pid' => $patientId,
                'category' => $category,
                'did' => $doctorId,
                'lid' => $labUserId,
                'ts' => $timestampMs,
                'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE),
            ]);

            Response::json(['ok' => true], 201);
            exit;
        }

        if ($method === 'GET' && count($parts) === 3) {
            $patientId = $parts[2];
            $category = isset($_GET['category']) ? (string)$_GET['category'] : '';
            if ($category !== '') {
                $stmt = $pdo->prepare('SELECT category,timestamp_ms,payload,created_at FROM lab_history WHERE patient_id=:pid AND category=:category ORDER BY timestamp_ms DESC LIMIT 200');
                $stmt->execute(['pid' => $patientId, 'category' => $category]);
            } else {
                $stmt = $pdo->prepare('SELECT category,timestamp_ms,payload,created_at FROM lab_history WHERE patient_id=:pid ORDER BY timestamp_ms DESC LIMIT 200');
                $stmt->execute(['pid' => $patientId]);
            }
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['payload'] = json_decode($r['payload'], true);
            }
            Response::json(['history' => $rows]);
            exit;
        }
    }

    if ($resource === 'lab-latest' && $method === 'GET' && count($parts) === 3) {
        $patientId = $parts[2];
        $stmt = $pdo->prepare('SELECT category,timestamp_ms,payload,updated_at FROM lab_latest WHERE patient_id=:pid ORDER BY updated_at DESC');
        $stmt->execute(['pid' => $patientId]);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $r['payload'] = json_decode($r['payload'], true);
        }
        Response::json(['latest' => $rows]);
        exit;
    }

    if ($resource === 'lab-tech-notifications' && count($parts) === 3) {
        $labId = strtoupper($parts[2]);
        if ($method === 'GET') {
            $stmt = $pdo->prepare('SELECT payload,created_at FROM lab_tech_notifications WHERE lab_user_id=:lid ORDER BY created_at DESC LIMIT 200');
            $stmt->execute(['lid' => $labId]);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['payload'] = json_decode($r['payload'], true);
            }
            Response::json(['notifications' => $rows]);
            exit;
        }
        if ($method === 'POST') {
            $stmt = $pdo->prepare('INSERT INTO lab_tech_notifications (lab_user_id,payload) VALUES (:lid,:payload)');
            $stmt->execute([
                'lid' => $labId,
                'payload' => json_encode($body['payload'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
            Response::json(['ok' => true], 201);
            exit;
        }
    }

    Response::json(['error' => 'Route not found'], 404);
} catch (Throwable $e) {
    Response::json([
        'error' => 'Internal server error',
        'detail' => ($config['debug'] ?? false) ? $e->getMessage() : null,
    ], 500);
}


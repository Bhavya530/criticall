import SwiftUI

struct RadiologyView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedTests: [String] = []
    var patient: PatientModel?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    
                    Text("Radiology")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 15)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.black)

                ScrollView {
                    VStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Select tests to perform")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal)

                        Text("Available Tests")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal)

                        VStack(spacing: 16) {
                            // Tension Pneumothorax
                            TestCategoryRow(
                                title: "Tension Pneumothorax",
                                subtitle: "Chest imaging finding",
                                tags: ["Tension Pneumothorax"],
                                isSelected: selectedTests.contains("Tension Pneumothorax")
                            ) {
                                toggleSelection(for: "Tension Pneumothorax")
                            }

                            // Pulmonary Embolism
                            TestCategoryRow(
                                title: "Pulmonary Embolism",
                                subtitle: "CT angiogram finding",
                                tags: ["Pulmonary Embolism"],
                                isSelected: selectedTests.contains("Pulmonary Embolism")
                            ) {
                                toggleSelection(for: "Pulmonary Embolism")
                            }

                            // Aortic Dissection
                            TestCategoryRow(
                                title: "Aortic Dissection",
                                subtitle: "Imaging for aortic tear",
                                tags: ["Aortic Dissection"],
                                isSelected: selectedTests.contains("Aortic Dissection")
                            ) {
                                toggleSelection(for: "Aortic Dissection")
                            }

                            // New Pneumoperitoneum
                            TestCategoryRow(
                                title: "New Pneumoperitoneum",
                                subtitle: "Free air under diaphragm",
                                tags: ["New Pneumoperitoneum"],
                                isSelected: selectedTests.contains("New Pneumoperitoneum")
                            ) {
                                toggleSelection(for: "New Pneumoperitoneum")
                            }

                            // Pulmonary Edema
                            TestCategoryRow(
                                title: "Pulmonary Edema",
                                subtitle: "Fluid overload on imaging",
                                tags: ["Pulmonary Edema"],
                                isSelected: selectedTests.contains("Pulmonary Edema")
                            ) {
                                toggleSelection(for: "Pulmonary Edema")
                            }
                        }
                        .padding(.horizontal)

                        // Alert Section
                        CommonAlertView()
                            .padding(.top, 10)
                    }
                    .padding(.bottom, 120)
                }
            }
            
            if !selectedTests.isEmpty {
                VStack {
                    Spacer()
                    NavigationLink(destination: LabParameterEntryView(patient: patient, selectedTests: selectedTests)) {
                        Text("PROCEED TO TEST ENTRY")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(Color.indigo) 
                            .cornerRadius(12)
                            .padding()
                    }
                    .background(
                        LinearGradient(gradient: Gradient(colors: [.black.opacity(0), .black]), startPoint: .top, endPoint: .bottom)
                            .padding(.top, -20)
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }

    private func toggleSelection(for test: String) {
        if selectedTests.contains(test) {
            selectedTests.removeAll(where: { $0 == test })
        } else {
            selectedTests.append(test)
        }
    }
}

#Preview {
    RadiologyView()
}

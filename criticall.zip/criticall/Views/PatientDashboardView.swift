import SwiftUI
import Charts

struct PatientDashboardView: View {
    @State private var medications: [APIManager.PatientMedication] = []
    @State private var labHistory: [LabHistoryModel] = []
    @State private var isLoading = true
    @State private var isHistoryLoading = true
    @State private var errorMessage: String?
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // HEADER
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Patient Portal")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                        if let user = APIManager.shared.currentUser {
                            Text("Welcome, \(user.name)")
                                .font(.subheadline)
                                .foregroundColor(.teal)
                        }
                    }
                    Spacer()
                    
                    Button(action: {
                        APIManager.shared.logout()
                        dismiss()
                    }) {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(8)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal)
                .padding(.top, 20)
                .padding(.bottom, 10)
                
                Divider().background(Color.white.opacity(0.1))
                
                // CONTENT
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .teal))
                                .frame(maxWidth: .infinity, alignment: .center)
                                .padding(.top, 20)
                        } else {
                            // TRENDS CHART
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Health Trends")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                
                                Text("Potassium Levels (mmol/L)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                    .padding(.horizontal)
                                
                                if isHistoryLoading {
                                    ProgressView()
                                        .frame(height: 200)
                                        .frame(maxWidth: .infinity)
                                } else if potassiumData.isEmpty {
                                    VStack(spacing: 8) {
                                        Image(systemName: "chart.line.uptrend.xyaxis")
                                            .font(.system(size: 40))
                                            .foregroundColor(.gray.opacity(0.3))
                                        Text("No health trends available yet.")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                        Text("Your metrics will appear here once tests are performed.")
                                            .font(.caption2)
                                            .foregroundColor(.gray.opacity(0.6))
                                            .multilineTextAlignment(.center)
                                    }
                                    .frame(height: 220)
                                    .frame(maxWidth: .infinity)
                                    .background(Color.white.opacity(0.02))
                                    .cornerRadius(16)
                                    .padding(.horizontal)
                                } else {
                                    Chart {
                                        ForEach(potassiumData) { data in
                                            LineMark(
                                                x: .value("Date", data.date),
                                                y: .value("Level", data.value)
                                            )
                                            .foregroundStyle(Color.teal)
                                            .interpolationMethod(.catmullRom)
                                            
                                            PointMark(
                                                x: .value("Date", data.date),
                                                y: .value("Level", data.value)
                                            )
                                            .foregroundStyle(data.value > 5.5 ? .red : .teal)
                                            .annotation(position: .top) {
                                                Text("\(String(format: "%.1f", data.value))")
                                                    .font(.caption2)
                                                    .foregroundColor(.white.opacity(0.8))
                                            }
                                        }
                                        
                                        // Normal range area
                                        RuleMark(y: .value("Normal High", 5.5))
                                            .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                                            .foregroundStyle(.gray.opacity(0.5))
                                        
                                        RuleMark(y: .value("Normal Low", 3.5))
                                            .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                                            .foregroundStyle(.gray.opacity(0.5))
                                    }
                                    .chartYScale(domain: 2...8)
                                    .frame(height: 220)
                                    .padding()
                                    .background(Color.white.opacity(0.05))
                                    .cornerRadius(16)
                                    .padding(.horizontal)
                                }
                            }
                            .padding(.top, 10)
                            
                            Text("My Prescriptions")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.horizontal)
                                .padding(.top, 24)
                            
                            if medications.isEmpty {
                                VStack(spacing: 16) {
                                    Image(systemName: "pills")
                                        .font(.system(size: 50))
                                        .foregroundColor(.gray.opacity(0.5))
                                    Text("No prescriptions found.")
                                        .foregroundColor(.gray)
                                }
                                .frame(maxWidth: .infinity, alignment: .center)
                                .padding(.top, 30)
                            } else {
                                ForEach(medications) { med in
                                    MedicationCard(medication: med)
                                        .padding(.horizontal)
                                }
                            }
                        }
                    }
                    .padding(.bottom, 30)
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            fetchMedications()
            fetchHistory()
        }
    }
    
    struct TrendPoint: Identifiable {
        var id = UUID()
        let date: Date
        let value: Double
    }
    
    var potassiumData: [TrendPoint] {
        var points: [TrendPoint] = []
        for h in labHistory {
            if let payload = h.payload, 
               let kVal = payload["potassium"]?.value as? String,
               let val = Double(kVal) {
                let date = Date(timeIntervalSince1970: Double(h.timestamp_ms) / 1000.0)
                points.append(TrendPoint(date: date, value: val))
            }
        }
        return points.sorted(by: { $0.date < $1.date })
    }
    
    private func fetchMedications() {
        guard let patientId = APIManager.shared.currentUser?.userId else { return }
        isLoading = true
        APIManager.shared.fetchPatientMedications(for: patientId) { meds, error in
            isLoading = false
            if let meds = meds {
                self.medications = meds
            }
        }
    }
    
    private func fetchHistory() {
        guard let patientId = APIManager.shared.currentUser?.userId else { return }
        isHistoryLoading = true
        APIManager.shared.fetchLabHistory(for: patientId) { history, error in
            isHistoryLoading = false
            if let history = history {
                self.labHistory = history
            }
        }
    }
}

struct MedicationCard: View {
    let medication: APIManager.PatientMedication
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "cross.case.fill")
                    .foregroundColor(.teal)
                Text("Prescribed by \(medication.doctor_user_id)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.gray)
                Spacer()
                Text(formatDate(medication.created_at))
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Divider().background(Color.white.opacity(0.1))
            
            Text(medication.medication_text)
                .font(.system(size: 15))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4)
        }
        .padding()
        .background(Color(red: 25/255, green: 28/255, blue: 32/255))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.05), lineWidth: 1)
        )
    }
    
    // Quick formatter for display
    private func formatDate(_ dateString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let date = formatter.date(from: dateString) {
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
        return dateString
    }
}

#Preview {
    PatientDashboardView()
}

import Foundation
import Combine

class DoctorDashboardViewModel: ObservableObject {
    @Published var patients: [PatientModel] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    @Published var activeAlertsCount = 0
    @Published var latestAlert: CriticalNotificationModel?
    @Published var criticalPatientsCount = 0
    
    // Store active notifications to compute derived counts
    private var activeAlerts: [CriticalNotificationModel] = []
    
    private var observer: Any?
    
    init() {
        observer = NotificationCenter.default.addObserver(forName: NSNotification.Name("PatientListUpdated"), object: nil, queue: .main) { [weak self] _ in
            self?.refreshData()
        }
    }
    
    func refreshData() {
        fetchPatients()
        fetchAlertCount()
    }
    
    // Derived properties for UI
    var activePatientsCount: Int { patients.count }
    var totalPatientsCount: Int { patients.count }
    
    func fetchPatients() {
        // ... previous logic ...
        guard let doctorId = APIManager.shared.currentUser?.userId else {
            let fallbackDoctorId = "DR001" 
            self.performFetch(doctorId: fallbackDoctorId)
            return
        }
        self.performFetch(doctorId: doctorId)
    }
    
    func fetchAlertCount() {
        guard let doctorId = APIManager.shared.currentUser?.userId ?? Optional("DR001") else { return }
        APIManager.shared.fetchCriticalNotifications(for: doctorId) { [weak self] notifications, _ in
            DispatchQueue.main.async {
                let active = notifications?.filter { $0.is_resolved == 0 } ?? []
                self?.activeAlerts = active
                self?.activeAlertsCount = active.count
                self?.latestAlert = active.first
                self?.recalculateCriticalPatients()
            }
        }
    }
    
    private func recalculateCriticalPatients() {
        let alertPatientIds = Set(activeAlerts.map { $0.patient_id })
        
        // Sync local patient statuses so the Recent Patients UI row updates correctly
        for i in 0..<patients.count {
            if alertPatientIds.contains(patients[i].patient_id) {
                patients[i].status = "Critical"
            }
        }
        
        let dbCriticalIds = Set(patients.filter { $0.dashboardStatus == .critical }.map { $0.patient_id })
        criticalPatientsCount = alertPatientIds.union(dbCriticalIds).count
    }
    
    private func performFetch(doctorId: String) {
        isLoading = true
        errorMessage = nil
        
        APIManager.shared.fetchPatients(for: doctorId) { [weak self] fetchedPatients, error in
            guard let self = self else { return }
            self.isLoading = false
            
            if let fetchedPatients = fetchedPatients {
                self.patients = fetchedPatients
                self.recalculateCriticalPatients()
            } else if let error = error {
                self.errorMessage = error
            }
        }
    }
}

//
//  LabReportEntry.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//

import SwiftUI

struct LabReportEntryScreen: View {
    @Environment(\.dismiss) var dismiss
    var patient: PatientModel?
    @State private var hemoglobin: String = ""
    @State private var hematocrit: String = ""
    @State private var platelets: String = ""
    @State private var wbc: String = ""
    @State private var inr: String = ""

    var body: some View {
        ZStack {
            Color(red: 10/255, green: 10/255, blue: 10/255)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 0) {
                // Custom Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    Spacer()
                    Text("Report Entry")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    // Empty space for balance
                    Image(systemName: "chevron.left").opacity(0)
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
                .padding(.bottom, 10)

                ScrollView {
                    VStack(spacing: 20) {
                        // Patient Card
                        VStack(alignment: .leading, spacing: 12) {
                            HStack(spacing: 15) {
                                Circle()
                                    .fill(Color.white.opacity(0.1))
                                    .frame(width: 50, height: 50)
                                    .overlay(
                                        Image(systemName: "person.fill")
                                            .foregroundColor(.blue)
                                    )
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(patient?.full_name ?? "Michael Chen")
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(.white)
                                    Text("ID: \(patient?.id ?? "P002") • \(String(describing: patient?.age ?? 67))y, \(patient?.gender ?? "Male")")
                                        .font(.system(size: 14))
                                        .foregroundColor(.gray)
                                }
                            }
                            
                            Divider().background(Color.white.opacity(0.1))
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Tests Ordered:")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.gray)
                                Text(patient?.tests_ordered ?? "CBC, Lipid Panel, BMP")
                                    .font(.system(size: 16))
                                    .foregroundColor(.white)
                            }
                        }
                        .padding(20)
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)

                        // Hematology Section
                        VStack(alignment: .leading, spacing: 20) {
                            HStack(spacing: 10) {
                                Image(systemName: "testtube.2")
                                    .foregroundColor(.blue)
                                Text("Hematology")
                                    .font(.system(size: 18, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            
                            VStack(spacing: 15) {
                                LabeledEntryField(label: "Hemoglobin", normal: "12–16 g/dL", placeholder: "Enter value", text: $hemoglobin)
                                LabeledEntryField(label: "Hematocrit", normal: "36–46 %", placeholder: "Enter value", text: $hematocrit)
                                LabeledEntryField(label: "Platelets", normal: "150–450", placeholder: "Enter value", text: $platelets)
                            }
                        }
                        .padding(20)
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)

                        // Action Button
                        Button(action: {
                            dismiss()
                        }) {
                            Text("Submit Report")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .background(Color.blue)
                                .cornerRadius(16)
                        }
                        .padding(.top, 10)
                    }
                    .padding(24)
                }
            }
        }
        .navigationBarHidden(true)
    }
}

// Custom field for label and normal value styling
struct LabeledEntryField: View {
    var label: String
    var normal: String
    var placeholder: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(label)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
                Text("(Normal: \(normal))")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            TextField(placeholder, text: $text)
                .padding(14)
                .background(Color.white.opacity(0.08))
                .cornerRadius(12)
                .font(.system(size: 14))
                .foregroundColor(.white)
        }
    }
}

struct LabReportEntryScreen_Previews: PreviewProvider {
    static var previews: some View {
        LabReportEntryScreen()
            .preferredColorScheme(.dark)
    }
}


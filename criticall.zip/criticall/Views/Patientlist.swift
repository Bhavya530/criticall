//
//  Patientlist.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//

import SwiftUI

struct PatientListScreen: View {

    @Environment(\.dismiss) private var dismiss

    @StateObject private var viewModel = DoctorDashboardViewModel()
    @State private var selectedTab: Tab = .all
    @State private var searchText: String = ""

    enum Tab: String, CaseIterable {
        case all = "All"
        case critical = "Critical"
        case stable = "Stable"

        var color: Color {
            switch self {
            case .all: return .teal
            case .critical: return .red
            case .stable: return .green
            }
        }
    }

    var filteredPatients: [PatientModel] {
        let filtered = viewModel.patients.filter {
            searchText.isEmpty ||
            $0.full_name.localizedCaseInsensitiveContains(searchText) ||
            $0.id.localizedCaseInsensitiveContains(searchText)
        }

        switch selectedTab {
        case .all: return filtered
        case .critical: return filtered.filter { $0.dashboardStatus == .critical }
        case .stable: return filtered.filter { $0.dashboardStatus != .critical }
        }
    }

    var body: some View {
        // Removed nested NavigationStack
        ZStack {
            Color.black.ignoresSafeArea()

                VStack {

                    // SEARCH
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search patients", text: $searchText)
                            .foregroundColor(.white)
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(12)
                    .padding()

                    // TABS
                    HStack {
                        ForEach(Tab.allCases, id: \.self) { tab in
                            Button {
                                selectedTab = tab
                            } label: {
                                Text(tab.rawValue)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 6)
                                    .background(selectedTab == tab ? tab.color : Color.gray.opacity(0.3))
                                    .foregroundColor(.white)
                                    .cornerRadius(16)
                            }
                        }
                        Spacer()
                    }
                    .padding(.horizontal)

                    // LIST
                    ScrollView {
                        VStack(spacing: 12) {
                            if viewModel.isLoading {
                                ProgressView()
                            } else {
                                ForEach(filteredPatients) { patient in
                                    HStack {
                                        VStack(alignment: .leading) {
                                            Text(patient.full_name)
                                                .foregroundColor(.black)
                                                .fontWeight(.semibold)
                                            Text("ID: \(patient.id) • \(patient.age ?? 0) yrs")
                                                .font(.caption)
                                                .foregroundColor(.gray)
                                        }
                                        Spacer()
                                        
                                        let status = patient.dashboardStatus
                                        let color: Color = (status == .critical) ? .red : ((status == .recovering) ? .blue : .green)
                                        
                                        Text(status.rawValue)
                                            .foregroundColor(color)
                                    }
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(14)
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Patient List")
            .onAppear {
                viewModel.fetchPatients()
            }
            // Removed .navigationBarTitleDisplayMode and .toolbar for macOS compatibility
    }
}

#Preview {
    PatientListScreen()
        .preferredColorScheme(.dark)
}


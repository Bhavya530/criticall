import SwiftUI

struct ContentView: View {
    @State private var selectedRole = "Doctor"
    let roles = ["Doctor", "Lab Technician", "Patient"]
    @State private var userID = ""
    @State private var password = ""
    @State private var showPassword = false
    
    @State private var goDoctorDashboard = false
    @State private var goLabDashboard = false
    @State private var goPatientDashboard = false
    @State private var goSignup = false
    @State private var goForgotPassword = false
    
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    @ObservedObject private var api = APIManager.shared
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    // MARK: - Logo Section
                    VStack(spacing: 12) {
                        Image("criticall_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .padding(.top, 20)
                        
                        Text("CritiCall Portal")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                        
                        Text("Secure Healthcare Management System")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    
                    Spacer().frame(height: 30)
                    
                    // MARK: - Login Card
                    VStack(alignment: .leading, spacing: 24) {
                        // Role Selector
                        HStack(spacing: 0) {
                            ForEach(roles, id: \.self) { role in
                                Button {
                                    withAnimation(.spring()) {
                                        selectedRole = role
                                    }
                                } label: {
                                    Text(role)
                                        .font(.system(size: 14, weight: .bold))
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(selectedRole == role ? Color.black : Color.clear)
                                        .foregroundColor(selectedRole == role ? .white : Color(white: 0.6))
                                        .cornerRadius(8)
                                }
                            }
                        }
                        .padding(4)
                        .background(Color(white: 0.12))
                        .cornerRadius(12)
                        
                        // Header
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(selectedRole) Sign In")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                            
                            Text(selectedRole == "Doctor" ? "Authorized physician access only" : (selectedRole == "Patient" ? "Patient portal access" : "Authorized lab personnel only"))
                                .font(.system(size: 13))
                                .foregroundColor(Color(white: 0.6))
                        }
                        
                        // User ID Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("User ID")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            HStack(spacing: 12) {
                                Image(systemName: "person.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .font(.system(size: 18))
                                
                                TextField("Enter \(selectedRole) ID", text: $userID)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                            }
                            .padding(.vertical, 14)
                            .padding(.horizontal, 16)
                            .background(Color(white: 0.1))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(white: 0.15), lineWidth: 1)
                            )
                        }
                        
                        // Password Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Password")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            HStack(spacing: 12) {
                                Image(systemName: "lock.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .font(.system(size: 18))
                                
                                if showPassword {
                                    TextField("Enter your password", text: $password)
                                        .foregroundColor(.white)
                                        .font(.system(size: 15))
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled(true)
                                } else {
                                    SecureField("Enter your password", text: $password)
                                        .foregroundColor(.white)
                                        .font(.system(size: 15))
                                }
                                
                                Button(action: {
                                    showPassword.toggle()
                                }) {
                                    Image(systemName: showPassword ? "eye.fill" : "eye.slash.fill")
                                        .foregroundColor(Color(white: 0.5))
                                        .padding(.vertical, 10)
                                }
                            }
                            .padding(.vertical, 14)
                            .padding(.horizontal, 16)
                            .background(Color(white: 0.1))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(white: 0.15), lineWidth: 1)
                            )
                        }
                        
                        if let errorMessage = errorMessage {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.system(size: 14))
                                .padding(.horizontal)
                        }
                        
                        // Sign In Button
                        Button {
                            isLoading = true
                            errorMessage = nil
                            
                            APIManager.shared.login(userId: userID, password: ["password": password]) { success, error in
                                isLoading = false
                                if success {
                                    if selectedRole == "Doctor" {
                                        goDoctorDashboard = true
                                    } else if selectedRole == "Lab Technician" {
                                        goLabDashboard = true
                                    } else if selectedRole == "Patient" {
                                        goPatientDashboard = true
                                    }
                                } else {
                                    errorMessage = error ?? "Login failed"
                                }
                            }
                        } label: {
                            if isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Text("Sign In as \(selectedRole)")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 15)
                                    .background(Color(red: 45/255, green: 110/255, blue: 245/255)) // Match the blue in mockup
                                    .cornerRadius(14)
                            }
                        }
                        .disabled(isLoading || userID.isEmpty || password.isEmpty)
                        .padding(.top, 4)
                        
                        // Forgot Password Link
                        if selectedRole != "Doctor" {
                            Button {
                                goForgotPassword = true
                            } label: {
                                Text("Forgot Password?")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(Color(red: 45/255, green: 110/255, blue: 245/255))
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                            }
                        }
                        
                        // Create Account Link
                        if selectedRole != "Doctor" {
                            Button {
                                goSignup = true
                            } label: {
                                HStack(spacing: 4) {
                                    Text("Don't have an account?")
                                        .foregroundColor(Color(white: 0.6))
                                    Text("Sign Up")
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(red: 45/255, green: 110/255, blue: 245/255))
                                }
                                .font(.system(size: 14))
                                .frame(maxWidth: .infinity)
                            }
                        }
                    }
                    .padding(24)
                    .background(Color(white: 0.08)) // Dark card background
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                    
                    Spacer().frame(height: 30)
                    
                    // Footer
                    Text("© 2024 CritiCall Portal. All rights reserved.")
                        .font(.system(size: 12))
                        .foregroundColor(Color(white: 0.5))
                        .padding(.bottom, 20)
                }
            }
            }
            .navigationDestination(isPresented: $goDoctorDashboard) {
                DoctorDashboardView()
            }
            .navigationDestination(isPresented: $goLabDashboard) {
                LabDashboardView()
            }
            .navigationDestination(isPresented: $goPatientDashboard) {
                PatientDashboardView()
            }
            .navigationDestination(isPresented: $goSignup) {
                SignupScreen()
            }
            .navigationDestination(isPresented: $goForgotPassword) {
                ForgotPasswordView()
            }
        .preferredColorScheme(.dark)
        .onChange(of: api.currentUser == nil) { oldVal, isLoggedOut in
            if isLoggedOut {
                goDoctorDashboard = false
                goLabDashboard = false
                goPatientDashboard = false
                userID = ""
                password = ""
            }
        }
    }
}

#Preview {
    ContentView()
}


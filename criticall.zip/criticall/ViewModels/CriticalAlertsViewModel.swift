import Foundation
import Combine

class CriticalAlertsViewModel: ObservableObject {
    @Published var activeAlerts: [CriticalNotificationModel] = []
    @Published var resolvedAlerts: [CriticalNotificationModel] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var activeCount: Int {
        activeAlerts.count
    }
    
    func fetchAlerts() {
        guard let doctorId = APIManager.shared.currentUser?.userId else {
            // Fallback for simulator testing
            performFetch(doctorId: "DR001")
            return
        }
        
        performFetch(doctorId: doctorId)
    }
    
    private func performFetch(doctorId: String) {
        isLoading = true
        errorMessage = nil
        
        APIManager.shared.fetchCriticalNotifications(for: doctorId) { [weak self] notifications, error in
            guard let self = self else { return }
            self.isLoading = false
            
            if let notifications = notifications {
                // Split them into active (is_resolved == 0) and resolved (is_resolved == 1)
                self.activeAlerts = notifications.filter { $0.is_resolved == 0 }
                self.resolvedAlerts = notifications.filter { $0.is_resolved == 1 }
            } else if let error = error {
                self.errorMessage = error
            }
        }
    }
    
    func resolveAlert(notificationId: String) {
        guard let doctorId = APIManager.shared.currentUser?.userId else {
            // Fallback
            performResolve(doctorId: "DR001", notificationId: notificationId)
            return
        }
        performResolve(doctorId: doctorId, notificationId: notificationId)
    }
    
    private func performResolve(doctorId: String, notificationId: String) {
        isLoading = true
        APIManager.shared.resolveAlert(doctorId: doctorId, notificationId: notificationId) { [weak self] success, error in
            guard let self = self else { return }
            if success {
                self.fetchAlerts()
            } else {
                self.isLoading = false
                self.errorMessage = error
            }
        }
    }
}

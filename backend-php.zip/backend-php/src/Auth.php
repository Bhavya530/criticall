<?php

declare(strict_types=1);

namespace Criticall;

use DateTimeImmutable;
use PDO;

final class Auth
{
    public function __construct(private PDO $pdo)
    {
    }

    public function createTokenForUserId(string $userId): ?string
    {
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE user_id = :uid LIMIT 1');
        $stmt->execute(['uid' => $userId]);
        $row = $stmt->fetch();
        if (!$row) {
            return null;
        }

        $token = bin2hex(random_bytes(32));
        $expiresAt = (new DateTimeImmutable('+30 days'))->format('Y-m-d H:i:s');

        $insert = $this->pdo->prepare('INSERT INTO api_tokens (user_id, token, expires_at) VALUES (:user_id, :token, :expires_at)');
        $insert->execute([
            'user_id' => $row['id'],
            'token' => $token,
            'expires_at' => $expiresAt,
        ]);

        return $token;
    }

    public function validateBearer(?string $header): ?array
    {
        if (!$header || !str_starts_with($header, 'Bearer ')) {
            return null;
        }
        $token = trim(substr($header, 7));
        if ($token === '') {
            return null;
        }

        $sql = 'SELECT u.user_id, u.role, u.name FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE t.token=:token AND t.expires_at > NOW() LIMIT 1';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['token' => $token]);
        $row = $stmt->fetch();

        return $row ?: null;
    }
}

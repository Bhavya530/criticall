import SwiftUI

struct ProfileView: View {
    @Binding var selectedTab: Int
    var onLogout: () -> Void
    @State private var showEditProfile = false
    @State private var showChangePassword = false
    @State private var showNotificationPrefs = false

    var body: some View {
            VStack(spacing: 0) {
                // Header
                HStack(spacing: 15) {
                    Button(action: {
                        selectedTab = 0
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    
                    Text("Profile")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Button(action: { showEditProfile = true }) {
                        Text("Edit")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Profile Header Card
                        VStack(spacing: 16) {
                            ZStack {
                                Circle()
                                    .fill(Color.white.opacity(0.1))
                                    .frame(width: 100, height: 100)
                                Text(String(APIManager.shared.currentUser?.name.prefix(1) ?? "L"))
                                    .font(.system(size: 38, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            
                            VStack(spacing: 4) {
                                Text(APIManager.shared.currentUser?.name ?? "Lab Technician")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundColor(.white)
                                Text("Lab Technician • \(APIManager.shared.currentUser?.department ?? "Microbiology")")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding(.vertical, 30)
                        
                        // ID Card Section
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Professional Info")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                            
                            VStack(spacing: 1) {
                                LabProfessionalInfoRow(label: "Employee ID", value: APIManager.shared.currentUser?.userId ?? "LT2024003")
                                Divider().background(Color.white.opacity(0.05))
                                LabProfessionalInfoRow(label: "Shift", value: "Day (7AM – 3PM)")
                                Divider().background(Color.white.opacity(0.05))
                                LabProfessionalInfoRow(label: "Supervisor", value: "Dr. Jesvanthan")
                            }
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                        }
                        
                        // Settings Section
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Account Settings")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                            
                            VStack(spacing: 1) {
                                SettingsButton(icon: "lock.fill", title: "Change Password") {
                                    showChangePassword = true
                                }
                                Divider().background(Color.white.opacity(0.05))
                                SettingsButton(icon: "bell.fill", title: "Notification Preferences") {
                                    showNotificationPrefs = true
                                }
                                Divider().background(Color.white.opacity(0.05))
                                SettingsButton(icon: "rectangle.portrait.and.arrow.right", title: "Logout", isDestructive: true) {
                                    onLogout()
                                }
                            }
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 20)
                }
            }
        .sheet(isPresented: $showEditProfile) {
            EditProfileView()
        }
        .sheet(isPresented: $showChangePassword) {
            ChangePasswordView()
        }
        .sheet(isPresented: $showNotificationPrefs) {
            NotificationPreferencesView()
        }
    }
}

struct LabProfessionalInfoRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .foregroundColor(.white)
                .fontWeight(.medium)
        }
        .padding(16)
    }
}

struct SettingsButton: View {
    let icon: String
    let title: String
    var isDestructive: Bool = false
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(isDestructive ? .red : .blue)
                    .frame(width: 24)
                Text(title)
                    .foregroundColor(isDestructive ? .red : .white)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
            }
            .padding(16)
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView(selectedTab: .constant(2), onLogout: {})
            .preferredColorScheme(.dark)
    }
}


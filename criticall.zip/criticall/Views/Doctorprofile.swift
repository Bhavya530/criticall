//  Doctorprofile.swift
//  criticall
//
//  Created by Hemanth Kumar on 27/02/26.
//

import SwiftUI

struct DoctorProfileView: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 40) {
                    VStack(spacing: 8) {
                        Circle()
                            .fill(Color(red: 0/255, green: 180/255, blue: 130/255))
                            .frame(width: 90, height: 90)
                            .overlay(
                                Image(systemName: "person.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .foregroundColor(.white)
                                    .padding(24)
                            )
                        VStack(spacing: 4) {
                            Text(APIManager.shared.currentUser?.name ?? "Doctor Profile")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.white)
                                .padding(.top, 4)
                            Text(Date(), style: .date)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            Text(APIManager.shared.currentUser?.department ?? "Medicine")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(Color(red: 0/255, green: 180/255, blue: 130/255))

                            Text("ID: \(APIManager.shared.currentUser?.userId ?? "DOC001")")
                                .foregroundColor(.gray)
                                .font(.subheadline)
                                .padding(.top, 4)
                            
                            if let email = APIManager.shared.currentUser?.email, !email.isEmpty {
                                Text(email)
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                            }
                            
                            Text("Ward 421, Floor 4") // Static for now until provided dynamically
                                .foregroundColor(.gray)
                                .font(.subheadline)
                                .padding(.top, 8)
                        }
                    }
                    .padding(.top, 40)
                    .frame(maxWidth: .infinity)
                    
                    AccountSettingsSection()
                    
                    VStack(spacing: 4) {
                        Text("CritiCall Portal v1.0.0 - Doctor Module")
                        Text("© 2024 Healthcare Solutions")
                    }
                    .font(.caption2)
                    .foregroundColor(.gray)
                    .padding(.top, 20)
                    .padding(.bottom, 40)
                }
                .padding(.top, 44) // Space for back button
            }
            
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "chevron.left")
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .frame(width: 44, height: 44)
                    .background(Color.white.opacity(0.1))
                    .clipShape(Circle())
            }
            .padding(.leading, 16)
            .padding(.top, 8)
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }
}

struct InfoRow: View {
    let iconName: String
    let label: String
    let value: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: iconName)
                .font(.title3)
                .foregroundColor(Color.teal.opacity(0.7))
                .frame(width: 36, height: 36)
                .background(Color.teal.opacity(0.15))
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text(value)
                    .foregroundColor(.white)
                    .font(.body)
                    .lineLimit(nil)
            }
            Spacer()
        }
    }
}

// Account Settings Section as a Separate View
struct AccountSettingsSection: View {
    @Environment(\.dismiss) var dismiss
    @State private var showEditProfile = false
    @State private var showChangePassword = false
    @State private var showNotificationPrefs = false
    @State private var showLogoutAlert = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Account Settings")
                .font(.title3)
                .bold()
                .foregroundColor(.white)
                .padding(.horizontal)
            
            VStack(spacing: 24) {
                accountSettingsRow(
                    iconName: "pencil",
                    title: "Edit Profile",
                    subtitle: "Update personal information",
                    action: { showEditProfile = true },
                    iconColor: Color(red: 0/255, green: 180/255, blue: 130/255)
                )
                
                accountSettingsRow(
                    iconName: "lock.fill",
                    title: "Change Password",
                    subtitle: "Update security credentials",
                    action: { showChangePassword = true },
                    iconColor: Color(red: 0/255, green: 180/255, blue: 130/255)
                )
                
                accountSettingsRow(
                    iconName: "bell.fill",
                    title: "Notification Preferences",
                    subtitle: "Manage alert settings",
                    action: { showNotificationPrefs = true },
                    iconColor: Color(red: 0/255, green: 180/255, blue: 130/255)
                )
                
                accountSettingsRow(
                    iconName: "rectangle.portrait.and.arrow.right",
                    title: "Logout",
                    subtitle: "Sign out of your account",
                    action: { showLogoutAlert = true },
                    iconColor: .red,
                    titleColor: .red,
                    subtitleColor: .gray
                )
            }
            .padding(.horizontal)
        }
        .padding(.horizontal, 4)
        .sheet(isPresented: $showEditProfile) {
            EditProfileView()
        }
        .sheet(isPresented: $showChangePassword) {
            ChangePasswordView()
        }
        .sheet(isPresented: $showNotificationPrefs) {
            NotificationPreferencesView()
        }
        .alert(isPresented: $showLogoutAlert) {
            Alert(
                title: Text("Confirm Logout"),
                message: Text("Are you sure you want to log out?"),
                primaryButton: .destructive(Text("Logout")) {
                    dismiss()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        APIManager.shared.logout()
                    }
                },
                secondaryButton: .cancel()
            )
        }
    }
    
    @ViewBuilder
    private func accountSettingsRow(
        iconName: String,
        title: String,
        subtitle: String,
        action: @escaping () -> Void,
        iconColor: Color = Color(red: 0/255, green: 180/255, blue: 130/255),
        titleColor: Color = .white,
        subtitleColor: Color = .gray
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 16) {
                Image(systemName: iconName)
                    .font(.title2)
                    .foregroundColor(iconColor)
                    .frame(width: 32, alignment: .center)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .foregroundColor(titleColor)
                        .font(.headline)
                    Text(subtitle)
                        .foregroundColor(subtitleColor)
                        .font(.subheadline)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
                    .font(.headline)
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    DoctorProfileView()
}

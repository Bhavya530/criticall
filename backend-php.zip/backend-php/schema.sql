CREATE DATABASE IF NOT EXISTS criticall CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE criticall;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role ENUM('Doctor','LabTechnician') NOT NULL,
    department VARCHAR(255) DEFAULT NULL,
    email VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(64) DEFAULT NULL,
    location VARCHAR(255) DEFAULT NULL,
    shift VARCHAR(255) DEFAULT NULL,
    supervisor VARCHAR(255) DEFAULT NULL,
    profile_image TEXT DEFAULT NULL,
    notification_preferences JSON DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS api_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    token CHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    email VARCHAR(255) NOT NULL,
    token CHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    KEY idx_prt_email (email),
    KEY idx_prt_expires (expires_at)
);

CREATE TABLE IF NOT EXISTS patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL,
    doctor_user_id VARCHAR(64) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(32) NOT NULL,
    contact_number VARCHAR(64) DEFAULT NULL,
    ward_room VARCHAR(128) DEFAULT NULL,
    diagnosis TEXT DEFAULT NULL,
    tests_ordered TEXT DEFAULT NULL,
    photo_url LONGTEXT DEFAULT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'Active',
    discharged TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_patient_per_doctor (doctor_user_id, patient_id)
);

CREATE TABLE IF NOT EXISTS test_results (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    doctor_user_id VARCHAR(64) NOT NULL,
    patient_id VARCHAR(64) NOT NULL,
    lab_user_id VARCHAR(64) NOT NULL,
    category VARCHAR(128) NOT NULL,
    payload JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS lab_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL,
    doctor_user_id VARCHAR(64) NOT NULL,
    lab_user_id VARCHAR(64) NOT NULL,
    category VARCHAR(128) NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    payload JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_lab_history_patient_ts (patient_id, timestamp_ms),
    KEY idx_lab_history_patient_category_ts (patient_id, category, timestamp_ms)
);

CREATE TABLE IF NOT EXISTS lab_latest (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL,
    category VARCHAR(128) NOT NULL,
    doctor_user_id VARCHAR(64) NOT NULL,
    lab_user_id VARCHAR(64) NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    payload JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_lab_latest_patient_category (patient_id, category),
    KEY idx_lab_latest_patient (patient_id)
);

CREATE TABLE IF NOT EXISTS critical_notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    notification_id VARCHAR(128) NOT NULL UNIQUE,
    doctor_user_id VARCHAR(64) NOT NULL,
    patient_id VARCHAR(64) NOT NULL,
    patient_name VARCHAR(255) DEFAULT NULL,
    payload JSON NOT NULL,
    is_resolved TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS predicted_alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    doctor_user_id VARCHAR(64) NOT NULL,
    patient_id VARCHAR(64) NOT NULL,
    payload JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_predicted (doctor_user_id, patient_id)
);

CREATE TABLE IF NOT EXISTS lab_tech_notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lab_user_id VARCHAR(64) NOT NULL,
    payload JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Seed users (username=password) for app bootstrap
INSERT INTO users (
    user_id,
    password_hash,
    name,
    role,
    department,
    email,
    phone,
    location,
    shift,
    supervisor,
    profile_image
) VALUES
('RES001','$2y$10$kSWEDdX6.cs6m5B9nIZQMuJKrItvJrDSmCuyb6YxT5Tl042MtxIJG','Dr. Jesvanthan','Doctor','Respiratory Medicine','jesvanthan@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('RES002','$2y$10$djNxMQ/Sw89RSaMeyJWNnur63/KNXBuIy47cdbZAjeBAE2X.KKW7G','Dr. Abinaya','Doctor','Respiratory Medicine','abinaya@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('RES003','$2y$10$rt/xJF2/AkdJK8OQsnafuu8w8gUKd02iiOqSfGQnZ7h2UqYiuI8BO','Dr. Santhosh','Doctor','Respiratory Medicine','santhosh@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('RES004','$2y$10$Tk.bRQeiR8O/DYwZ.Wd4/u8t/XgH.rsrBPTllGlrGmnqt/wUN034q','Dr. Harish','Doctor','Respiratory Medicine','harish@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('RES005','$2y$10$euTr2tIhxsXhWVrc6wqbyeX4YBOC1UWWZ3SJF.eMiLwSFnVATF8Cm','Dr. Priyanka','Doctor','Respiratory Medicine','priyanka@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('RES006','$2y$10$OPeOD/J2mLhn3SFQici54eLgFuoNGk.1HG9latSwvYFsTZ2MXJ9W6','Dr. Rajkumar','Doctor','Respiratory Medicine','rajkumar@saveetha.com','','Respiratory Block','Day Shift','Chief Respiratory Consultant',''),
('LAB003','$2y$10$bp6MjtfQoVOIrUwRsA8lAekU8aD64PVZd7uzDs76ooAwidI.o.4hO','Karthik','LabTechnician','Microbiology','karthik@saveetha.com','','Central Lab','Day Shift','Lab Supervisor',''),
('LAB004','$2y$10$tb0O0JmfmLFsJxh7W6UayOMnmWln/3BnVwBOjICQngxWMY1zVrLj.','Meena','LabTechnician','Biochemistry','meena@saveetha.com','','Central Lab','Day Shift','Lab Supervisor',''),
('LAB005','$2y$10$aXtPaRAamYLLwqzatRfhF.fEokHxAo8GamxkX7oCLWhUb/IrHnDgW','Siva','LabTechnician','Hematology','siva@saveetha.com','','Central Lab','Day Shift','Lab Supervisor',''),
('LAB006','$2y$10$9UIFga6z6q3/oWa8t0sYmeXosa7qtBMg2RdxT3rsoLZTSxFFLiLyO','Divya','LabTechnician','Clinical Pathology','divya@saveetha.com','','Central Lab','Day Shift','Lab Supervisor',''),
('LAB007','$2y$10$ObytCV37mER1cR9qmJ3nSeATrN7ZrfqlgQN9ilyk6nbuUmKWQVmge','Arun','LabTechnician','Immunology','arun@saveetha.com','','Central Lab','Day Shift','Lab Supervisor',''),
('LAB008','$2y$10$JqGu9lgqrJX7IkEXGrcwDOfBaB6iRTQDQUCykxeAYjk9z2PkVZcT6','Nisha','LabTechnician','Radiology Lab','nisha@saveetha.com','','Central Lab','Day Shift','Lab Supervisor','')
ON DUPLICATE KEY UPDATE
    password_hash = VALUES(password_hash),
    name = VALUES(name),
    role = VALUES(role),
    department = VALUES(department),
    email = VALUES(email),
    phone = VALUES(phone),
    location = VALUES(location),
    shift = VALUES(shift),
    supervisor = VALUES(supervisor),
    profile_image = VALUES(profile_image),
    updated_at = CURRENT_TIMESTAMP;

import SwiftUI
struct SignupScreen: View {
    @State private var selectedRole = "Doctor"
    let roles = ["Doctor", "Lab Technician"]
    @State private var userID = ""
    @State private var password = ""
    @State private var showPassword = false
    @State private var name = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var department = "Microbiology" // Default
    
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    @State private var goToDoctorDashboard = false
    @State private var goToLabDashboard = false
    @Environment(\.dismiss) var dismiss
    
    @ObservedObject private var api = APIManager.shared
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    // MARK: - Logo Section
                    VStack(spacing: 12) {
                        Image("criticall_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .padding(.top, 20)
                        
                        Text("CritiCall Portal")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                        
                        Text("Secure Healthcare Management System")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    
                    Spacer().frame(height: 30)
                    
                    // MARK: - Signup Card
                    VStack(alignment: .leading, spacing: 24) {
                        // Role Selector
                        HStack(spacing: 0) {
                            ForEach(roles, id: \.self) { role in
                                Button {
                                    withAnimation(.spring()) {
                                        selectedRole = role
                                    }
                                } label: {
                                    Text(role)
                                        .font(.system(size: 14, weight: .bold))
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(selectedRole == role ? Color.black : Color.clear)
                                        .foregroundColor(selectedRole == role ? .white : Color(white: 0.6))
                                        .cornerRadius(8)
                                }
                            }
                        }
                        .padding(4)
                        .background(Color(white: 0.12))
                        .cornerRadius(12)
                        
                        // Header
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(selectedRole) Sign Up")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                            
                            Text("Create your \(selectedRole.lowercased()) account")
                                .font(.system(size: 13))
                                .foregroundColor(Color(white: 0.6))
                        }
                        
                        // Common Fields
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Full Name")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            TextField("Enter full name", text: $name)
                                .foregroundColor(.white)
                                .font(.system(size: 15))
                                .padding(.vertical, 14)
                                .padding(.horizontal, 16)
                                .background(Color(white: 0.1))
                                .cornerRadius(12)
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Email Address")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            TextField("Enter email", text: $email)
                                .foregroundColor(.white)
                                .font(.system(size: 15))
                                .padding(.vertical, 14)
                                .padding(.horizontal, 16)
                                .background(Color(white: 0.1))
                                .cornerRadius(12)
                        }

                        // User ID Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("User ID")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            HStack(spacing: 12) {
                                Image(systemName: "person.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .font(.system(size: 18))
                                
                                TextField("Enter \(selectedRole) ID", text: $userID)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                            }
                            .padding(.vertical, 14)
                            .padding(.horizontal, 16)
                            .background(Color(white: 0.1))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(white: 0.15), lineWidth: 1)
                            )
                        }
                        
                        // Password Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Password")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(Color(white: 0.8))
                            
                            HStack(spacing: 12) {
                                Image(systemName: "lock.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .font(.system(size: 18))
                                
                                if showPassword {
                                    TextField("Enter your password", text: $password)
                                        .foregroundColor(.white)
                                        .font(.system(size: 15))
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled(true)
                                } else {
                                    SecureField("Enter your password", text: $password)
                                        .foregroundColor(.white)
                                        .font(.system(size: 15))
                                }
                                
                                Button(action: {
                                    showPassword.toggle()
                                }) {
                                    Image(systemName: showPassword ? "eye.fill" : "eye.slash.fill")
                                        .foregroundColor(Color(white: 0.5))
                                        .padding(.vertical, 8)
                                }
                            }
                            .padding(.vertical, 14)
                            .padding(.horizontal, 16)
                            .background(Color(white: 0.1))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(white: 0.15), lineWidth: 1)
                            )
                        }
                        
                        if let errorMessage = errorMessage {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.system(size: 14))
                                .padding(.top, 4)
                        }

                        // Sign Up Button
                        Button {
                            isLoading = true
                            errorMessage = nil
                            
                            if selectedRole == "Lab Technician" {
                                APIManager.shared.signupLabTech(userId: userID, name: name, password: ["password": password], email: email, phone: phone, department: department) { success, error in
                                    isLoading = false
                                    if success {
                                        goToLabDashboard = true
                                    } else {
                                        errorMessage = error ?? "Signup failed"
                                    }
                                }
                            } else {
                                APIManager.shared.signupDoctor(userId: userID, name: name, password: ["password": password], email: email, phone: phone, department: department) { success, error in
                                    isLoading = false
                                    if success {
                                        goToDoctorDashboard = true
                                    } else {
                                        errorMessage = error ?? "Signup failed"
                                    }
                                }
                            }
                        } label: {
                            if isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Text("Sign Up as \(selectedRole)")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 15)
                                    .background(Color(red: 45/255, green: 110/255, blue: 245/255))
                                    .cornerRadius(14)
                            }
                        }
                        .disabled(isLoading || userID.isEmpty || password.isEmpty || name.isEmpty || email.isEmpty)
                        .padding(.top, 4)
                    }
                    .padding(24)
                    .background(Color(white: 0.08))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                    
                    Spacer().frame(height: 30)
                    
                    // Footer
                    Text("© 2024 CritiCall Portal. All rights reserved.")
                        .font(.system(size: 12))
                        .foregroundColor(Color(white: 0.5))
                        .padding(.bottom, 20)
                }
            }
            
            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                        .padding()
                    }
                    Spacer()
                }
                Spacer()
            }
        }
            .navigationDestination(isPresented: $goToDoctorDashboard) {
                DoctorDashboardView()
            }
            .navigationDestination(isPresented: $goToLabDashboard) {
                LabDashboardView()
            }
            .navigationBarHidden(true)
        .preferredColorScheme(.dark)
        .onChange(of: api.currentUser == nil) { oldVal, isLoggedOut in
            if isLoggedOut {
                goToDoctorDashboard = false
                goToLabDashboard = false
                userID = ""
                password = ""
                name = ""
                email = ""
                phone = ""
            }
        }
    }
}

#Preview {
    SignupScreen()
}


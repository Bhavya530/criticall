import Foundation
import Combine

// MARK: - API Response Models
struct BackendResponse<T: Codable>: Codable {
    let patients: [T]?
    let error: String?
}

struct PatientModel: Codable, Identifiable {
    var id: String { patient_id }
    let patient_id: String
    let full_name: String
    let age: Int?
    let gender: String?
    let contact_number: String?
    let ward_room: String?
    let diagnosis: String?
    let tests_ordered: String?
    var status: String?
    let ordering_physician: String?
    let doctor_user_id: String?
    
    var dashboardStatus: PatientStatus {
        switch status?.lowercased() {
        case "critical": return .critical
        case "recovering": return .recovering
        default: return .stable
        }
    }
}

// MARK: - Notification Models
struct NotificationResponse: Codable {
    let notifications: [CriticalNotificationModel]?
    let error: String?
}

struct NotificationPayload: Codable {
    let alertType: String?
    let value: String?
    let normalRange: String?
}

struct CriticalNotificationModel: Codable, Identifiable {
    var id: String { notification_id }
    let notification_id: String
    let patient_id: String
    let patient_name: String?
    let payload: NotificationPayload?
    let is_resolved: Int
    let created_at: String?
    let updated_at: String?
}


enum PatientStatus: String {
    case stable = "Stable"
    case critical = "Critical"
    case recovering = "Recovering"
}

struct LabLatestResponse: Codable {
    let latest: [LabLatestModel]?
    let error: String?
}

// Custom decoding to allow payload to be arbitrary JSON types via Dictionary if needed, 
// but since JSONDecoder with [String: String] will fail if value is not a string, 
// using AnyCodable or string dictionary. For simplicity we will use nested [String: String] if possible, 
// or since SwiftUI's JSON is usually stringified data, let's use [String: String]? or Any type payload?
// If we check the lab tech submissions, they usually pass string values. 
// We will use [String: String]? for payload.
struct LabLatestModel: Codable, Identifiable {
    var id: String { category }
    let category: String
    let timestamp_ms: Int
    let payload: [String: AnyDecodable]?
    let updated_at: String?
}

struct LabHistoryResponse: Codable {
    let history: [LabHistoryModel]?
    let error: String?
}

struct LabHistoryModel: Codable, Identifiable {
    var id: String { "\(category)_\(timestamp_ms)" }
    let category: String
    let timestamp_ms: Int
    let payload: [String: AnyDecodable]?
    let created_at: String?
}

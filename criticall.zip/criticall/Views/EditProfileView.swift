import SwiftUI 
struct EditProfileView: View {
    @Environment(\.dismiss) var dismiss
    @State private var fullName: String = "Dr. Jesvanthan"
    @State private var department: String = "Respiratory Medicine"
    @State private var email: String = "jesvanthan@saveetha.com"
    @State private var phone: String = "+91 9442042428"
    @State private var location: String = "Ward 421, Floor 4"
    var body: some View {
        ZStack {
            Color(red: 10/255, green: 14/255, blue: 22/255)
                .edgesIgnoringSafeArea(.all)
            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 44, height: 44)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    Spacer()
                    
                    Text("Edit Profile")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.trailing, 44) // Balance the back button
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 30)
                .padding(.bottom, 30)

                ScrollView {
                    VStack(alignment: .leading, spacing: 25){
                        // Full Name
                        CustomEditField(label: "Full Name", placeholder: "Enter your full name", text: $fullName)                                                                                                                                   
                        // Department
                        CustomEditField(label: "Department", placeholder: "Enter department", text: $department)
                        
                        // Email
                        CustomEditField(label: "Email", placeholder: "Enter email", text: $email)
                        
                        // Phone
                        CustomEditField(label: "Phone", placeholder: "Enter phone number", text: $phone)
                        
                        // Location
                        CustomEditField(label: "Location", placeholder: "Enter location", text: $location)
                        
                        // Action Buttons
                        HStack(spacing: 20) {
                            Button(action: {
                                dismiss()
                            }) {
                                Text("SAVE")
                                    .font(.system(size: 16,weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 16)
                                    .background(Color(red: 45/255, green: 115/255, blue: 235/255))
                                    .cornerRadius(12)
                            }
                            
                            Button(action: {
                                dismiss()
                            }) {
                                Text("CANCEL") 
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 16)
                                    .background(Color.white.opacity(0.2))
                                    .cornerRadius(12)
                            }
                        }
                        .padding(.top, 10)
                        // Profile Update Tips
                        VStack(alignment: .leading, spacing: 15) {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Profile Update Tips:")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.leading, 55)
                                
                                HStack(alignment: .top, spacing: 15) {
                                    Image(systemName: "info.circle.fill")
                                        .font(.system(size: 30))
                                        .foregroundColor(Color(red: 45/255, green: 115/255, blue: 235/255))
                                    
                                    VStack(alignment: .leading, spacing: 12) {
                                        HStack(spacing: 8) {
                                            Image(systemName: "checkmark")
                                                .font(.system(size: 12, weight: .black))
                                                .foregroundColor(.white)
                                            Text("Use your official full name")
                                                .font(.system(size: 15))
                                                .foregroundColor(.white)
                                        }
                                        HStack(spacing: 8) {
                                            Image(systemName: "checkmark")
                                                .font(.system(size: 12, weight: .black))
                                                .foregroundColor(.white)
                                            Text("Enter valid department and email")
                                                .font(.system(size: 15))
                                                .foregroundColor(.white)
                                        }
                                    }
                                }
                            }
                            .padding(20)
                            .background(Color(red: 18/255, green: 22/255, blue: 33/255))
                            .cornerRadius(16)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                            )
                        }
                        .padding(.top, 20)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct CustomEditField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
            
            ZStack(alignment: .leading) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(placeholder)
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                    
                    TextField("", text: $text)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.white.opacity(0.08))
                .cornerRadius(12)
            }
        }
    }
}

#Preview {
    EditProfileView()
}

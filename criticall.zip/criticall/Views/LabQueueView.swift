import SwiftUI

struct LabQueueView: View {
    @Binding var selectedTab: Int
    @State private var searchText = ""
    @State private var sortOption = "Name (A-Z)"
    @State private var showSortMenu = false
    
    @StateObject private var viewModel = LabQueueViewModel()
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 15) {
                Button(action: {
                    selectedTab = 0
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                }
                
                Text("Patient Report Entry")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            
            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search by name or ID", text: $searchText)
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 15)
            .padding(.vertical, 12)
            .background(Color.white.opacity(0.1))
            .cornerRadius(12)
            .padding(.horizontal, 20)
            .padding(.top, 30)
            
            // Choose Patient Section
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Choose Patient")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Text("Select a patient to enter lab results")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                }
                Spacer()
                
                // Sort Button/Menu
                Menu {
                    Button("Name (A-Z)") { sortOption = "Name (A-Z)" }
                    Button("Name (Z-A)") { sortOption = "Name (Z-A)" }
                    Button("Patient ID") { sortOption = "Patient ID" }
                    Button("Age (Low to High)") { sortOption = "Age (Low to High)" }
                    Button("Age (High to Low)") { sortOption = "Age (High to Low)" }
                } label: {
                    HStack {
                        Text(sortOption)
                            .font(.system(size: 14, weight: .semibold))
                        Image(systemName: "chevron.down")
                            .font(.system(size: 10))
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.white.opacity(0.05))
                    .cornerRadius(8)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 40)
            
            // Patient List
            ScrollView {
                VStack(spacing: 16) {
                    if viewModel.isLoading {
                        ProgressView("Loading queue...")
                            .foregroundColor(.white)
                    } else if let error = viewModel.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                    } else if viewModel.queuePatients.isEmpty {
                        Text("No patients in queue.")
                            .foregroundColor(.gray)
                    } else {
                        // Filtering sorted/queued patients
                        let filtered = viewModel.queuePatients.filter {
                            searchText.isEmpty || $0.full_name.localizedCaseInsensitiveContains(searchText) || $0.id.localizedCaseInsensitiveContains(searchText)
                        }
                        
                        ForEach(filtered) { patient in
                            NavigationLink(destination: LabCategoryView(patient: patient)) {
                                PatientRowView(patient: patient)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
            .onAppear {
                viewModel.fetchQueuedPatients()
            }
            
            Spacer()
        }
    }
}

struct PatientRowView: View {
    let patient: PatientModel
    
    var body: some View {
        HStack(spacing: 16) {
            // Patient Image
            Image(systemName: "person.crop.rectangle.fill")
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
                .foregroundColor(.gray.opacity(0.5))
                .background(Color.white.opacity(0.1))
                .cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(patient.full_name)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Text("\(patient.age ?? 0)y, \(patient.gender ?? "")")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                }
                
                Text("ID: \(patient.id)")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                
                Divider()
                    .background(Color.white.opacity(0.1))
                    .padding(.vertical, 4)
                
                HStack(spacing: 8) {
                    Text("Tests Reported:")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                    
                    // In real data, you might split a comma-separated string `patient.tests_ordered`
                    let tests = patient.tests_ordered?.components(separatedBy: ",") ?? []
                    ForEach(tests, id: \.self) { test in
                        let trimmed = test.trimmingCharacters(in: .whitespaces)
                        if !trimmed.isEmpty {
                            Text(trimmed)
                                .font(.system(size: 11))
                                .foregroundColor(.white)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.white.opacity(0.1))
                                .clipShape(Capsule())
                        }
                    }
                }
                .padding(.top, 4)
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.05))
        .cornerRadius(16)
    }
}

#Preview {
    LabQueueView(selectedTab: .constant(1))
}

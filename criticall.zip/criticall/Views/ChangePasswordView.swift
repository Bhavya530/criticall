import SwiftUI

struct ChangePasswordView: View {
    @Environment(\.dismiss) var dismiss
    
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    
    var body: some View {
        ZStack {
            Color(red: 13/255, green: 17/255, blue: 23/255)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Header with Back Button
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    .padding(.leading, 20)
                    
                    Spacer()
                }
                .padding(.top, 20)
                
                Text("Change Password")
                    .font(.system(size: 32, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 20)
                    .padding(.bottom, 30)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 25) {
                        // Current Password
                        SecureCustomField(label: "Current Password", placeholder: "Enter current password", text: $currentPassword)
                        
                        // New Password
                        SecureCustomField(label: "New Password", placeholder: "Enter new password", text: $newPassword)
                        
                        // Confirm Password
                        SecureCustomField(label: "Confirm Password", placeholder: "Confirm new password", text: $confirmPassword)
                        
                        // Action Button
                        Button(action: {
                            // Update password action
                            dismiss()
                        }) {
                            Text("UPDATE PASSWORD")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(12)
                        }
                        .padding(.top, 10)
                        
                        // Security Tips
                        VStack(alignment: .leading, spacing: 15) {
                            HStack(alignment: .top, spacing: 15) {
                                Image(systemName: "shield.lefthalf.filled")
                                    .font(.title2)
                                    .foregroundColor(.blue.opacity(0.7))
                                
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Security Tips:")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    
                                    BulletPoint(text: "Use at least 8 characters")
                                    BulletPoint(text: "Include a mix of letters, numbers, and symbols")
                                    BulletPoint(text: "Avoid using common words or names")
                                }
                            }
                            .padding()
                            .background(Color(red: 20/255, green: 25/255, blue: 35/255))
                            .cornerRadius(16)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                            )
                        }
                        .padding(.top, 20)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 40)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct SecureCustomField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    @State private var showPassword = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.headline)
                .foregroundColor(.white)
            
            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                        .foregroundColor(.gray)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 14)
                }
                
                HStack {
                    if showPassword {
                        TextField("", text: $text)
                            .foregroundColor(.white)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                    } else {
                        SecureField("", text: $text)
                            .foregroundColor(.white)
                    }
                    
                    Button(action: {
                        showPassword.toggle()
                    }) {
                        Image(systemName: showPassword ? "eye.fill" : "eye.slash.fill")
                            .foregroundColor(.gray)
                            .padding(.vertical, 8)
                            .padding(.leading, 8)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
            }
            .background(Color.white.opacity(0.1))
            .cornerRadius(12)
            .overlay(
                VStack {
                    HStack {
                        Text(placeholder)
                            .font(.caption)
                            .foregroundColor(.gray)
                            .padding(.horizontal, 4)
                            .background(Color(red: 13/255, green: 17/255, blue: 23/255))
                            .padding(.leading, 12)
                            .offset(y: -10)
                        Spacer()
                    }
                    Spacer()
                }
                .opacity(text.isEmpty ? 0 : 1)
            )
        }
    }
}

struct BulletPoint: View {
    let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 5) {
            Image(systemName: "checkmark.shield")
                .font(.caption.bold())
                .foregroundColor(.blue)
            Text(text)
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
        }
    }
}

#Preview {
    ChangePasswordView()
}

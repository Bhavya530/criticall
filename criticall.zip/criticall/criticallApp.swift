import SwiftUI

@main
struct criticallApp: App {
    var body: some Scene {
        WindowGroup {
            IntroView()
        }
    }
}

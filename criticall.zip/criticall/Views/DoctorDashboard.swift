import SwiftUI

// MARK: - MAIN DASHBOARD VIEW
struct DoctorDashboardView: View {
    @Environment(\.dismiss) var dismiss
    
    // MARK: ViewModel
    @StateObject private var viewModel = DoctorDashboardViewModel()

    // MARK: State
    @State private var goToPatientList = false
    @State private var goToAlerts = false
    @State private var goToProfile = false
    @State private var goToAddNewPatient = false
    @State private var goToAlertsList = false
    @State private var showCriticalPopup = true
    @ObservedObject private var api = APIManager.shared

    // Data is now fetched via ViewModel.

    var body: some View {
        VStack(spacing: 0) {
            // HEADER
            HStack {
                Circle()
                    .fill(Color.green)
                    .frame(width: 54, height: 54)
                    .overlay(
                        Image(systemName: "person")
                            .foregroundColor(.black)
                    )

                VStack(alignment: .leading) {
                    Text("Welcome, \(APIManager.shared.currentUser?.name ?? "Doctor")")
                        .font(.title2)
                        .foregroundColor(.white)
                    Text(Date(), style: .date)
                        .foregroundColor(.gray)
                }

                Spacer()

                Button(action: {
                    goToAlerts = true
                }) {
                    Image(systemName: "bell")
                        .foregroundColor(.gray)
                }
            }
            .padding()

            // CONTENT
            ScrollView {
                VStack(spacing: 16) {
                    if viewModel.activeAlertsCount > 0 {
                        Button(action: { goToAlerts = true }) {
                            HStack {
                                Image(systemName: "exclamationmark.octagon.fill")
                                Text("\(viewModel.activeAlertsCount) critical alerts require immediate attention.")
                                    .fontWeight(.bold)
                                Spacer()
                                Image(systemName: "chevron.right")
                            }
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                        .padding(.horizontal)
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }

                    DashboardCard(
                        icon: "waveform.path.ecg",
                        label: "Active Patients",
                        value: "\(viewModel.activePatientsCount)",
                        urgent: false
                    )

                    DashboardCard(
                        icon: "person.2.fill",
                        label: "Total Patients",
                        value: "\(viewModel.totalPatientsCount)",
                        urgent: false
                    )

                    DashboardCard(
                        icon: "exclamationmark.triangle.fill",
                        label: "Critical Patients",
                        value: "\(viewModel.criticalPatientsCount)",
                        urgent: viewModel.criticalPatientsCount > 0
                    )

                    HStack {
                        Text("Recent Patients")
                            .font(.headline)
                            .foregroundColor(.white)
                        Spacer()
                        Button("View All") {
                            goToPatientList = true
                        }
                        .foregroundColor(.teal)
                    }
                    .padding(.horizontal)

                    if viewModel.isLoading {
                        ProgressView("Loading patients...")
                            .foregroundColor(.white)
                    } else if let error = viewModel.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                    } else if viewModel.patients.isEmpty {
                        Text("No patients found.")
                            .foregroundColor(.gray)
                    } else {
                        ForEach(viewModel.patients) { patient in
                            NavigationLink(destination: PatientDetailsView(patient: patient)) {
                                PatientRow(patient: patient)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
            }

            // TAB BAR
            HStack {
                TabBarItem(icon: "square.grid.2x2.fill", label: "Dashboard", active: true)

                Spacer()

                Button {
                    goToPatientList = true
                } label: {
                    TabBarItem(icon: "person.2", label: "Patients", active: false)
                }

                Spacer()

                Button {
                    goToAlertsList = true
                } label: {
                    TabBarItem(icon: "bell", label: "Alerts", active: false)
                }

                Spacer()

                Button {
                    goToProfile = true
                } label: {
                    TabBarItem(icon: "person.crop.circle", label: "Profile", active: false)
                }
            }
            .padding()
            .background(Color.black)
        }
        .overlay(
            ZStack {
                // Floating Action Button
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: {
                            goToAddNewPatient = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(.white)
                                .frame(width: 60, height: 60)
                                .background(Color.green)
                                .clipShape(Circle())
                                .shadow(radius: 4)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 80) // Above tab bar
                    }
                }
                
                // Critical Alert Popup Overlay
                if showCriticalPopup, let latestAlert = viewModel.latestAlert {
                    Color.black.opacity(0.85).ignoresSafeArea()
                        .onTapGesture { showCriticalPopup = false }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        // Header
                        HStack(spacing: 12) {
                            Image(systemName: "bell.badge.fill")
                                .foregroundColor(.green)
                                .font(.system(size: 20))
                                .padding(10)
                                .background(Circle().fill(Color.green.opacity(0.2)))
                                
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Critical Notifications")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                Text("Immediate attention recommended — tap to view details")
                                    .font(.system(size: 11))
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            Button(action: { showCriticalPopup = false }) {
                                Image(systemName: "xmark")
                                    .foregroundColor(.white)
                                    .font(.title2)
                            }
                        }
                        .padding()
                        
                        Divider().background(Color.red).frame(height: 2)
                        
                        // Body Details
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Patient: \(latestAlert.patient_name ?? "Unknown") (ID: \(latestAlert.patient_id)) — \(latestAlert.payload?.alertType?.components(separatedBy: " ").last ?? "Lab")")
                                .foregroundColor(.white)
                                .font(.subheadline)
                            
                            Text("\(latestAlert.payload?.alertType?.replacingOccurrences(of: "Critical ", with: "") ?? ""): \(latestAlert.payload?.value ?? "") • Critical (\(latestAlert.payload?.normalRange ?? ""))")
                                .bold()
                                .foregroundColor(.white)
                                .font(.subheadline)
                            
                            Text("Time: \(latestAlert.created_at ?? "")")
                                .foregroundColor(.gray)
                                .font(.subheadline)
                        }
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(10)
                        .padding()
                        
                        // Actions
                        HStack(spacing: 20) {
                            Spacer()
                            Button("Dismiss") { showCriticalPopup = false }
                                .foregroundColor(.teal)
                                .font(.subheadline)
                            
                            Button("View Alerts") {
                                showCriticalPopup = false
                                goToAlerts = true
                            }
                            .foregroundColor(.white)
                            .font(.system(size: 14, weight: .bold))
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(Color.teal)
                            .cornerRadius(10)
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 20)
                    }
                    .background(Color(red: 30/255, green: 30/255, blue: 30/255))
                    .cornerRadius(20)
                    .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 10)
                    .padding(20)
                    .transition(.opacity.combined(with: .scale))
                }
            }
        )
        .background(Color.black.ignoresSafeArea())
        .navigationDestination(isPresented: $goToPatientList) {
            PatientListScreen()
        }
        .navigationDestination(isPresented: $goToAlerts) {
            CriticalAlertsView()
        }
        .navigationDestination(isPresented: $goToProfile) {
            DoctorProfileView()
        }
        .navigationDestination(isPresented: $goToAddNewPatient) {
            AddNewPatientView()
        }
        .navigationDestination(isPresented: $goToAlertsList) {
            CriticalAlertsListView()
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            viewModel.refreshData()
        }
        .onChange(of: api.currentUser == nil) { oldVal, isLoggedOut in
            if isLoggedOut {
                goToPatientList = false
                goToAlerts = false
                goToProfile = false
                goToAddNewPatient = false
                goToAlertsList = false
                dismiss()
            }
        }
    }
}

// MARK: - DASHBOARD CARD
struct DashboardCard: View {
    let icon: String
    let label: String
    let value: String
    let urgent: Bool

    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.blue)

            VStack(alignment: .leading) {
                Text(label).foregroundColor(.gray)
                Text(value)
                    .font(.title2)
                    .foregroundColor(.white)
            }

            Spacer()

            if urgent {
                Text("Urgent")
                    .foregroundColor(.white)
                    .padding(6)
                    .background(Color.red)
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.3))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - PATIENT ROW
struct PatientRow: View {
    let patient: PatientModel

    var body: some View {
        HStack {
            Text(patient.full_name)
                .foregroundColor(.white)
            Spacer()
            
            // Map the ViewModel's dashboardStatus to UI color/text
            let status = patient.dashboardStatus
            let color: Color = (status == .critical) ? .red : ((status == .recovering) ? .blue : .green)
            let labelText = status.rawValue
            
            Text(labelText)
                .foregroundColor(color)
        }
        .padding()
        .background(Color.gray.opacity(0.3))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - TAB BAR ITEM
struct TabBarItem: View {
    let icon: String
    let label: String
    let active: Bool

    var body: some View {
        VStack {
            Image(systemName: icon)
                .foregroundColor(active ? .teal : .gray)
            Text(label)
                .font(.caption)
                .foregroundColor(active ? .teal : .gray)
        }
    }
}

#Preview {
    DoctorDashboardView()
        .preferredColorScheme(.dark)
}

//
//  DoctorDashboard.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//


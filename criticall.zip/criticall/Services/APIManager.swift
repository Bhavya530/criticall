import Foundation
import SwiftUI
import Combine

class APIManager: ObservableObject {
    static let shared = APIManager()
    
    // Points to the PHP built-in server we started on port 8080
    private let baseURL = "http://localhost/backend-php/public/index.php/api"

    
    @Published var currentUser: User?
    @Published var authToken: String?
    
    struct User: Codable {
        let userId: String
        let name: String
        let role: String
        let email: String?
        let department: String?
    }
    
    func login(userId: String, password: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/auth/login")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "userId": userId,
            "password": password["password"] as? String ?? ""
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(false, "No data received")
                    return
                }
                
                do {
                    if let str = String(data: data, encoding: .utf8) {
                        print("Backend Response: \(str)")
                    }
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let token = json["token"] as? String {
                            self.authToken = token
                            if let userData = json["user"] as? [String: Any],
                               let jsonData = try? JSONSerialization.data(withJSONObject: userData) {
                                self.currentUser = try? JSONDecoder().decode(User.self, from: jsonData)
                            }
                            completion(true, nil)
                        } else if let errorMsg = json["error"] as? String {
                            completion(false, errorMsg)
                        } else {
                            completion(false, "Unknown error")
                        }
                    }
                } catch {
                    completion(false, "Failed to parse response")
                }
            }
        }.resume()
    }
    
    func signupLabTech(userId: String, name: String, password: [String: Any], email: String, phone: String, department: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/auth/signup-labtech")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "userId": userId,
            "name": name,
            "password": password["password"] as? String ?? "",
            "email": email,
            "phone": phone,
            "department": department
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(false, "No data received")
                    return
                }
                
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true {
                        completion(true, nil)
                    } else if let errorMsg = json["error"] as? String {
                        completion(false, errorMsg)
                    } else {
                        completion(false, "Signup failed")
                    }
                } else {
                    completion(false, "Failed to parse response")
                }
            }
        }.resume()
    }
    
    func signupDoctor(userId: String, name: String, password: [String: Any], email: String, phone: String, department: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/auth/signup-doctor")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "userId": userId,
            "name": name,
            "password": password["password"] as? String ?? "",
            "email": email,
            "phone": phone,
            "department": department
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(false, "No data received")
                    return
                }
                
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true {
                        completion(true, nil)
                    } else if let errorMsg = json["error"] as? String {
                        completion(false, errorMsg)
                    } else {
                        completion(false, "Signup failed")
                    }
                } else {
                    completion(false, "Failed to parse response")
                }
            }
        }.resume()
    }
    
    // MARK: - Password Reset Flow
    func checkUserId(userId: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/auth/check-id")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = ["userId": userId]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error { completion(false, error.localizedDescription); return }
                guard let data = data else { completion(false, "No data received"); return }
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true { completion(true, nil) }
                    else { completion(false, (json["error"] as? String) ?? "Invalid ID") }
                } else { completion(false, "Parse error") }
            }
        }.resume()
    }
    
    func resetPasswordDirect(userId: String, newPassword: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/auth/reset-password")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = ["userId": userId, "newPassword": newPassword["password"] as? String ?? ""]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error { completion(false, error.localizedDescription); return }
                guard let data = data else { completion(false, "No data received"); return }
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true { completion(true, nil) }
                    else { completion(false, (json["error"] as? String) ?? "Failed to reset password") }
                } else { completion(false, "Parse error") }
            }
        }.resume()
    }

    // MARK: - Patient API
    func fetchPatients(for doctorId: String, completion: @escaping ([PatientModel]?, String?) -> Void) {
        let url = URL(string: "\(baseURL)/patients/\(doctorId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    // Let's print the raw string to debug if needed
                    // if let str = String(data: data, encoding: .utf8) { print("Raw Data:", str) }
                    
                    let decoder = JSONDecoder()
                    // If your PHP backend returns snake_case, but our struct has exact names (patient_id, full_name, etc), it will match!
                    
                    let response = try decoder.decode(BackendResponse<PatientModel>.self, from: data)
                    
                    if let patients = response.patients {
                        completion(patients, nil)
                    } else if let errorMsg = response.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                    
                } catch {
                    completion(nil, "Failed to decode patients: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
    
    // For Lab Technicians
    func fetchAllPatients(completion: @escaping ([PatientModel]?, String?) -> Void) {
        let url = URL(string: "\(baseURL)/patients")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let response = try decoder.decode(BackendResponse<PatientModel>.self, from: data)
                    
                    if let patients = response.patients {
                        completion(patients, nil)
                    } else if let errorMsg = response.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                } catch {
                    completion(nil, "Failed to decode all patients: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
    
    // MARK: - Alerts API
    func fetchCriticalNotifications(for doctorId: String, completion: @escaping ([CriticalNotificationModel]?, String?) -> Void) {
        let url = URL(string: "\(baseURL)/critical-notifications/\(doctorId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(NotificationResponse.self, from: data)
                    
                    if let notifications = result.notifications {
                        completion(notifications, nil)
                    } else if let errorMsg = result.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                } catch {
                    completion(nil, "Failed to decode notifications: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
    func addPatient(doctorId: String, patientData: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/patients/\(doctorId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: patientData)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(false, "No data received")
                    return
                }
                
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true || (response as? HTTPURLResponse)?.statusCode == 201 {
                        completion(true, nil)
                    } else if let errorMsg = json["error"] as? String {
                        completion(false, errorMsg)
                    } else {
                        completion(false, "Failed to add patient")
                    }
                } else {
                    completion(false, "Failed to parse response")
                }
            }
        }.resume()
    }
    
    func postPatientMedication(patientId: String, doctorId: String, medicationText: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/patient-medications")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        let body: [String: Any] = [
            "patientId": patientId,
            "doctorId": doctorId,
            "medicationText": medicationText
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                if let response = response as? HTTPURLResponse, response.statusCode == 201 || response.statusCode == 200 {
                    completion(true, nil)
                } else {
                    completion(false, "Failed to save medication")
                }
            }
        }.resume()
    }
    
    struct PatientMedication: Codable, Identifiable {
        let id: Int
        let patient_id: String
        let doctor_user_id: String
        let medication_text: String
        let created_at: String
    }
    
    struct PatientMedicationResponse: Codable {
        let medications: [PatientMedication]?
        let error: String?
    }
    
    func fetchPatientMedications(for patientId: String, completion: @escaping ([PatientMedication]?, String?) -> Void) {
        // Must match the endpoint GET /api/patient-medications/{patientId}
        guard let encodedPatientId = patientId.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "\(baseURL)/patient-medications/\(encodedPatientId)") else {
            completion(nil, "Invalid patient ID")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(PatientMedicationResponse.self, from: data)
                    
                    if let meds = result.medications {
                        completion(meds, nil)
                    } else if let errorMsg = result.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                } catch {
                    completion(nil, "Failed to decode medications: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
    
    func logout() {
        self.currentUser = nil
        self.authToken = nil
    }

    // MARK: - Lab Report API
    func fetchLabLatest(for patientId: String, completion: @escaping ([LabLatestModel]?, String?) -> Void) {
        let url = URL(string: "\(baseURL)/lab-latest/\(patientId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(LabLatestResponse.self, from: data)
                    if let latest = result.latest {
                        completion(latest, nil)
                    } else if let errorMsg = result.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                } catch {
                    completion(nil, "Failed to decode lab latest: \(error.localizedDescription)")
                }
            }
        }.resume()
    }

    func fetchLabHistory(for patientId: String, category: String? = nil, completion: @escaping ([LabHistoryModel]?, String?) -> Void) {
        var urlString = "\(baseURL)/lab-history/\(patientId)"
        if let cat = category, !cat.isEmpty {
            urlString += "?category=\(cat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        }
        
        guard let url = URL(string: urlString) else {
            completion(nil, "Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(nil, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(nil, "No data received")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(LabHistoryResponse.self, from: data)
                    if let history = result.history {
                        completion(history, nil)
                    } else if let errorMsg = result.error {
                        completion(nil, errorMsg)
                    } else {
                        completion([], nil)
                    }
                } catch {
                    completion(nil, "Failed to decode lab history: \(error.localizedDescription)")
                }
            }
        }.resume()
    }

    func submitLabReport(patientId: String, doctorId: String, labUserId: String, category: String, payload: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/lab-history")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        let body: [String: Any] = [
            "patientId": patientId,
            "doctorId": doctorId,
            "labUserId": labUserId,
            "category": category,
            "payload": payload,
            "timestampMs": Int(Date().timeIntervalSince1970 * 1000)
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                guard let data = data else {
                    completion(false, "No data received")
                    return
                }
                
                if let str = String(data: data, encoding: .utf8) {
                    print("Submit Report Response: \(str)")
                }
                
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if json["ok"] as? Bool == true || (response as? HTTPURLResponse)?.statusCode == 201 {
                        completion(true, nil)
                    } else if let errorMsg = json["error"] as? String {
                        completion(false, errorMsg)
                    } else {
                        completion(false, "Failed to submit lab report")
                    }
                } else {
                    completion(false, "Failed to parse response")
                }
            }
        }.resume()
    }

    // MARK: - Critical Notifications API
    func postCriticalNotification(doctorId: String, patientId: String, patientName: String, alertType: String, value: String, normalRange: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/critical-notifications/\(doctorId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        let body: [String: Any] = [
            "notificationId": UUID().uuidString,
            "patientId": patientId,
            "patientName": patientName,
            "payload": [
                "alertType": alertType,
                "value": value,
                "normalRange": normalRange
            ]
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                if let response = response as? HTTPURLResponse, response.statusCode == 201 || response.statusCode == 200 {
                    completion(true, nil)
                } else {
                    completion(false, "Failed to post critical notification")
                }
            }
        }.resume()
    }


    func updatePatientStatus(doctorId: String, patientId: String, status: String, discharged: Bool, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/patients/\(doctorId)/\(patientId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        let body: [String: Any] = [
            "status": status,
            "discharged": discharged
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                    completion(true, nil)
                } else {
                    completion(false, "Failed to update patient status")
                }
            }
        }.resume()
    }

    func resolveAlert(doctorId: String, notificationId: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "\(baseURL)/critical-notifications/\(doctorId)/\(notificationId)/resolve")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                    return
                }
                
                if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                    completion(true, nil)
                } else {
                    completion(false, "Failed to resolve alert")
                }
            }
        }.resume()
    }
}

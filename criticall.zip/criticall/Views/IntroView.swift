import SwiftUI

struct IntroView: View {
    @State private var isVisible = false
    @State private var navigateToLogin = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                Color.black.ignoresSafeArea()
                
                // Animated background glow
                RadialGradient(
                    gradient: Gradient(colors: [Color(red: 45/255, green: 110/255, blue: 245/255).opacity(0.15), .black]),
                    center: .center,
                    startRadius: 10,
                    endRadius: 500
                )
                .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Spacer()
                    
                    // Logo Section
                    VStack(spacing: 20) {
                        Image("criticall_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 180, height: 180)
                            .clipShape(Circle())
                            .scaleEffect(isVisible ? 1 : 0.8)
                            .opacity(isVisible ? 1 : 0)
                        
                        VStack(spacing: 8) {
                            Text("CritiCall Portal")
                                .font(.system(size: 36, weight: .bold))
                                .foregroundColor(.white)
                            
                            Text("Advanced Critical Care Monitoring")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                        .offset(y: isVisible ? 0 : 20)
                        .opacity(isVisible ? 1 : 0)
                    }
                    
                    Spacer()
                    
                    // Features / Teaser (Micro-animations)
                    VStack(alignment: .leading, spacing: 15) {
                        FeatureRow(icon: "bolt.fill", title: "Real-time Alerts", subtitle: "Instant notifications for critical lab values.")
                        FeatureRow(icon: "doc.text.fill", title: "Smart Reporting", subtitle: "Streamlined test entry and automated analysis.")
                        FeatureRow(icon: "shield.fill", title: "Secure Access", subtitle: "HIPAA-compliant data management for hospitals.")
                    }
                    .padding(.horizontal, 30)
                    .offset(y: isVisible ? 0 : 30)
                    .opacity(isVisible ? 1 : 0)
                    
                    Spacer()
                    
                    // Get Started Button
                    Button {
                        withAnimation {
                            navigateToLogin = true
                        }
                    } label: {
                        HStack {
                            Text("GET STARTED")
                                .font(.system(size: 18, weight: .bold))
                            Image(systemName: "arrow.right")
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.teal, Color.cyan]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(15)
                        .shadow(color: Color.teal.opacity(0.3), radius: 10, x: 0, y: 5)
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 30)
                    .offset(y: isVisible ? 0 : 40)
                    .opacity(isVisible ? 1 : 0)
                }
            }
            .onAppear {
                withAnimation(.easeOut(duration: 0.8).delay(0.2)) {
                    isVisible = true
                }
            }
            .navigationDestination(isPresented: $navigateToLogin) {
                ContentView()
            }
        }
    }
}

struct FeatureRow: View {
    let icon: String
    let title: String
    let subtitle: String
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(.teal)
                .frame(width: 40, height: 40)
                .background(Color.white.opacity(0.1))
                .cornerRadius(10)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundColor(.gray)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

#Preview {
    IntroView()
}

import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct AddNewPatientView: View {
    @State private var patientID = ""
    @State private var fullName = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var contactNumber = ""
    @State private var wardRoom = ""
    @State private var diagnosis = ""
    @Environment(\.dismiss) var dismiss
    @State private var isSaving = false
    @State private var errorMessage: String?
    @State private var showPhotoOptions = false
    @State private var showImagePicker = false
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var selectedImage: UIImage? = nil
    @State private var selectedImageData: Data? = nil

    let genders = ["Male", "Female", "Other"]

    var body: some View {
        // Removed nested NavigationView
        Form {
                Section {
                    HStack {
                        Spacer()
                        Button(action: {
                            showPhotoOptions = true
                        }) {
                            if let selectedImageData,
                               let uiImage = UIImage(data: selectedImageData) {
                                Image(uiImage: uiImage)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            } else {
                                VStack {
                                    Image(systemName: "person.crop.circle.badge.plus")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 80, height: 80)
                                        .foregroundColor(.gray)
                                    Text("Add Photo")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                        .padding(.top, 4)
                                }
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                        .confirmationDialog("Select Photo Source", isPresented: $showPhotoOptions, titleVisibility: .visible) {
                            Button("Camera") {
                                imageSourceType = .camera
                                showImagePicker = true
                            }
                            Button("Gallery") {
                                imageSourceType = .photoLibrary
                                showImagePicker = true
                            }
                            Button("CANCEL", role: .cancel) {}
                        }
                        Spacer()
                    }
                }
                .listRowBackground(Color.clear)
                
                Section(header: Text("Patient ID *")) {
                    TextField("Enter patient ID", text: $patientID)
#if os(iOS)
                        .textInputAutocapitalization(.never)
#endif
                }
                Section(header: Text("Full Name *")) {
                    TextField("Enter full name", text: $fullName)
#if os(iOS)
                        .textInputAutocapitalization(.words)
#endif
                }
                Section(header: Text("Age *")) {
                    TextField("Enter age", text: $age)
#if os(iOS)
                        .keyboardType(.numberPad)
#endif
                }
                Section(header: Text("Gender *")) {
                    Picker("Select gender", selection: $gender) {
                        ForEach(genders, id: \.self) { Text($0) }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
                Section(header: Text("Contact Number *")) {
                    TextField("Enter contact number", text: $contactNumber)
#if os(iOS)
                        .keyboardType(.phonePad)
#endif
                }
                Section(header: Text("Ward/Room *")) {
                    TextField("Enter ward or room number", text: $wardRoom)
                }
                
                Section(header:
                            HStack {
                    Text("Diagnosis").fontWeight(.semibold)
                    Text("(Optional)").foregroundColor(.secondary)
                }) {
                    ZStack(alignment: .topLeading) {
                        if diagnosis.isEmpty {
                            Text("Enter diagnosis or medical notes")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 4)
                        }
                        TextEditor(text: $diagnosis)
                            .frame(minHeight: 80, maxHeight: 120)
                            .padding(4)
                            .background(Color.secondary.opacity(0.1))
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                    }
                    
                    // Save Patient button placed inside same section after diagnosis

                    Button(action: {
                        guard !patientID.isEmpty, !fullName.isEmpty, !age.isEmpty, !gender.isEmpty else {
                            errorMessage = "Please fill in all required fields"
                            return
                        }
                        
                        isSaving = true
                        errorMessage = nil
                        
                        let doctorId = APIManager.shared.currentUser?.userId ?? ""
                        var patientData: [String: Any] = [
                            "patientId": patientID,
                            "fullName": fullName,
                            "age": Int(age) ?? 0,
                            "gender": gender,
                            "contactNumber": contactNumber,
                            "wardRoom": wardRoom,
                            "diagnosis": diagnosis,
                            "testsOrdered": "",
                            "status": "Active",
                            "discharged": false
                        ]
                        
                        if let imageData = selectedImageData {
                            patientData["photo"] = imageData.base64EncodedString()
                        }
                        
                        APIManager.shared.addPatient(doctorId: doctorId, patientData: patientData) { success, error in
                            isSaving = false
                            if success {
                                NotificationCenter.default.post(name: NSNotification.Name("PatientListUpdated"), object: nil)
                                dismiss()
                            } else {
                                errorMessage = error ?? "Failed to save patient"
                            }
                        }
                    }) {
                        HStack {
                            if isSaving {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Image(systemName: "tray.and.arrow.down")
                                Text("Save Patient")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .frame(height: 48)
                    .background(Color.teal)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.top, 8)
                    .disabled(isSaving)
                    
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.system(size: 14))
                            .padding(.top, 4)
                    }
                }
            }
            .navigationTitle("Add New Patient")
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImage: $selectedImage, selectedImageData: $selectedImageData, sourceType: imageSourceType)
                    .ignoresSafeArea()
            }
        .preferredColorScheme(.dark)
    }
}

struct AddNewPatientView_Previews: PreviewProvider {
    static var previews: some View {
        AddNewPatientView()
            .preferredColorScheme(.dark)
    }
}

//
//  AddNewPatient.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//


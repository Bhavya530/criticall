import SwiftUI

struct ArterialBloodGasView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedTests: [String] = []
    var patient: PatientModel?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    
                    Text("ABG")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 15)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.black)

                ScrollView {
                    VStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Select tests to perform")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal)

                        Text("Available Tests")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal)

                        VStack(spacing: 16) {
                            // pH
                            TestCategoryRow(
                                title: "pH",
                                subtitle: "Arterial blood gas pH",
                                tags: ["pH"],
                                isSelected: selectedTests.contains("pH")
                            ) {
                                toggleSelection(for: "pH")
                            }

                            // pCO2
                            TestCategoryRow(
                                title: "pCO2",
                                subtitle: "Arterial carbon dioxide",
                                tags: ["pCO2"],
                                isSelected: selectedTests.contains("pCO2")
                            ) {
                                toggleSelection(for: "pCO2")
                            }

                            // pO2
                            TestCategoryRow(
                                title: "pO2",
                                subtitle: "Arterial oxygen",
                                tags: ["pO2"],
                                isSelected: selectedTests.contains("pO2")
                            ) {
                                toggleSelection(for: "pO2")
                            }
                        }
                        .padding(.horizontal)

                        // Alert Section
                        CommonAlertView()
                            .padding(.top, 10)
                    }
                    .padding(.bottom, 120)
                }
            }
            
            if !selectedTests.isEmpty {
                VStack {
                    Spacer()
                    NavigationLink(destination: LabParameterEntryView(patient: patient, selectedTests: selectedTests)) {
                        Text("PROCEED TO TEST ENTRY")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(Color.teal) 
                            .cornerRadius(12)
                            .padding()
                    }
                    .background(
                        LinearGradient(gradient: Gradient(colors: [.black.opacity(0), .black]), startPoint: .top, endPoint: .bottom)
                            .padding(.top, -20)
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }

    private func toggleSelection(for test: String) {
        if selectedTests.contains(test) {
            selectedTests.removeAll(where: { $0 == test })
        } else {
            selectedTests.append(test)
        }
    }
}

#Preview {
    ArterialBloodGasView()
}

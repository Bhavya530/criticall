<?php

declare(strict_types=1);

namespace Criticall;

final class SmtpMailer
{
    private string $host;
    private int $port;
    private string $username;
    private string $password;
    private string $encryption;
    private int $timeout;

    public function __construct(array $config)
    {
        $this->host = (string)($config['host'] ?? '');
        $this->port = (int)($config['port'] ?? 587);
        $this->username = (string)($config['username'] ?? '');
        $this->password = (string)($config['password'] ?? '');
        $this->encryption = strtolower((string)($config['encryption'] ?? 'none'));
        $this->timeout = (int)($config['timeout'] ?? 15);
    }

    public function send(string $from, string $to, string $subject, string $body): void
    {
        $transportHost = $this->host;
        if ($this->encryption === 'ssl') {
            $transportHost = 'ssl://' . $transportHost;
        }

        $socket = @stream_socket_client(
            $transportHost . ':' . $this->port,
            $errno,
            $errstr,
            $this->timeout
        );

        if (!$socket) {
            throw new \RuntimeException('SMTP connect failed: ' . $errstr . ' (' . $errno . ')');
        }

        stream_set_timeout($socket, $this->timeout);
        $this->expect($socket, [220]);
        $this->command($socket, 'EHLO criticall.local', [250]);

        if ($this->encryption === 'tls') {
            $this->command($socket, 'STARTTLS', [220]);
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new \RuntimeException('SMTP STARTTLS failed');
            }
            $this->command($socket, 'EHLO criticall.local', [250]);
        }

        if ($this->username !== '' || $this->password !== '') {
            $this->command($socket, 'AUTH LOGIN', [334]);
            $this->command($socket, base64_encode($this->username), [334]);
            $this->command($socket, base64_encode($this->password), [235]);
        }

        $this->command($socket, 'MAIL FROM:<' . $from . '>', [250]);
        $this->command($socket, 'RCPT TO:<' . $to . '>', [250, 251]);
        $this->command($socket, 'DATA', [354]);

        $headers = [
            'From: ' . $from,
            'To: ' . $to,
            'Subject: ' . $subject,
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
        ];
        $data = implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.";
        $this->command($socket, $data, [250]);
        $this->command($socket, 'QUIT', [221]);
        fclose($socket);
    }

    private function command($socket, string $command, array $expectedCodes): void
    {
        fwrite($socket, $command . "\r\n");
        $this->expect($socket, $expectedCodes);
    }

    private function expect($socket, array $expectedCodes): void
    {
        $line = '';
        do {
            $chunk = fgets($socket, 515);
            if ($chunk === false) {
                break;
            }
            $line = $chunk;
        } while (isset($line[3]) && $line[3] === '-');

        if ($line === '') {
            throw new \RuntimeException('SMTP empty response');
        }

        $code = (int)substr($line, 0, 3);
        if (!in_array($code, $expectedCodes, true)) {
            throw new \RuntimeException('SMTP unexpected response: ' . trim($line));
        }
    }
}


import Foundation
import Combine

class LabQueueViewModel: ObservableObject {
    @Published var queuePatients: [PatientModel] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchQueuedPatients() {
        isLoading = true
        errorMessage = nil
        
        APIManager.shared.fetchAllPatients { [weak self] patients, error in
            guard let self = self else { return }
            self.isLoading = false
            
            if let patients = patients {
                // In a real app, you might filter to those with pending "tests_ordered"
                self.queuePatients = patients
            } else if let error = error {
                self.errorMessage = error
            }
        }
    }
}

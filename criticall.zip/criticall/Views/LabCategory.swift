import SwiftUI

struct LabCategory: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let icon: String
    let color: Color
}

struct LabCategoryView: View {
    @Environment(\.dismiss) var dismiss
    var patient: PatientModel?
    
    // Grid layout configuration
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    let categories: [LabCategory] = [
        LabCategory(name: "Hematology", description: "Blood cell analysis and counts", icon: "flame.fill", color: Color.red.opacity(0.3)),
        LabCategory(name: "Biochemistry", description: "Chemical analysis of blood", icon: "testtube.2", color: Color.blue.opacity(0.3)),
        LabCategory(name: "Microbiology", description: "Bacterial and viral detection", icon: "allergens", color: Color.green.opacity(0.3)),
        LabCategory(name: "Coagulation Profile", description: "Blood clotting analysis", icon: "bolt.heart.fill", color: Color.purple.opacity(0.3)),
        LabCategory(name: "Cytology", description: "Cell examination and analysis", icon: "eye.circle.fill", color: Color.orange.opacity(0.3)),
        LabCategory(name: "ABG", description: "Arterial blood gas analysis", icon: "wind", color: Color.teal.opacity(0.3)),
        LabCategory(name: "Radiology", description: "Imaging and scan results", icon: "waveform.path", color: Color.indigo.opacity(0.3))
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                headerSection
                gridSection
                guideSection
            }
        }
        .background(Color.black.ignoresSafeArea())
        .navigationTitle("")
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }
    
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Button(action: { dismiss() }) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
            }
            .padding(.bottom, 8)

            Text("Choose Test Category")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.white)
            
            Text("Select the type of laboratory test to perform")
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding(.horizontal)
        .padding(.top, 16)
    }
    
    private var gridSection: some View {
        LazyVGrid(columns: columns, spacing: 16) {
            ForEach(categories) { category in
                NavigationLink(destination: destinationView(for: category.name)) {
                    VStack(alignment: .leading, spacing: 8) {
                        Image(systemName: category.icon)
                            .font(.system(size: 28))
                            .foregroundColor(category.color)
                            .frame(width: 50, height: 50)
                            .background(category.color.opacity(0.2))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        
                        Text(category.name)
                            .font(.headline)
                            .foregroundColor(.white)
                        
                        Text(category.description)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.05))
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.05), lineWidth: 1)
                    )
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding()
    }
    
    private var guideSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Start Guide")
                .font(.headline)
                .foregroundColor(.white)
            
            Text("Select a category to view available tests. Each test will guide you through parameter entry with automatic critical value detection.")
                .font(.subheadline)
                .foregroundColor(.gray)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .background(Color.white.opacity(0.03))
        .cornerRadius(16)
        .padding(.horizontal)
    }
    
    @ViewBuilder
    private func destinationView(for categoryName: String) -> some View {
        switch categoryName {
        case "Hematology": HematologyTestsView(patient: patient)
        case "Biochemistry": BioChemistryTestsView(patient: patient)
        case "Microbiology": MicrobiologyView(patient: patient)
        case "Coagulation Profile": CoagulationProfileView(patient: patient)
        case "Cytology": CytologyView(patient: patient)
        case "ABG": ArterialBloodGasView(patient: patient)
        case "Radiology": RadiologyView(patient: patient)
        default: Text("Coming Soon")
        }
    }
}

#Preview {
    LabCategoryView(patient: nil)
}

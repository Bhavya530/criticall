import SwiftUI

struct BioChemistryTestsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedTests: [String] = []
    var patient: PatientModel?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    
                    Text("Biochemistry")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 15)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.black)

                ScrollView {
                    VStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Select tests to perform")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal)

                        Text("Available Tests")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal)

                        VStack(spacing: 16) {
                            // Electrolytes
                            TestCategoryRow(
                                title: "Electrolytes",
                                subtitle: "Electrolyte panel",
                                tags: ["Sodium", "Potassium", "Calcium (Total)", "+3 more"],
                                isSelected: selectedTests.contains("Electrolytes")
                            ) {
                                toggleSelection(for: "Electrolytes")
                            }

                            // Basic Chemistry
                            TestCategoryRow(
                                title: "Basic Chemistry",
                                subtitle: "Basic metabolic panel",
                                tags: ["Glucose", "Lactate", "Bicarbonate", "+3 more"],
                                isSelected: selectedTests.contains("Basic Chemistry")
                            ) {
                                toggleSelection(for: "Basic Chemistry")
                            }

                            // RFT
                            TestCategoryRow(
                                title: "Renal Function Tests (RFT)",
                                subtitle: "Renal panel (critical thresholds)",
                                tags: ["Uric Acid"],
                                isSelected: selectedTests.contains("RFT")
                            ) {
                                toggleSelection(for: "RFT")
                            }

                            // LFT
                            TestCategoryRow(
                                title: "Liver Function Tests (LFT)",
                                subtitle: "Liver panel (critical thresholds)",
                                tags: ["Total Bilirubin", "Direct Bilirubin", "AST (SGOT)", "+3 more"],
                                isSelected: selectedTests.contains("LFT")
                            ) {
                                toggleSelection(for: "LFT")
                            }
                        }
                        .padding(.horizontal)

                        // Alert Section
                        CommonAlertView()
                            .padding(.top, 10)
                    }
                    .padding(.bottom, 120)
                }
            }
            
            if !selectedTests.isEmpty {
                VStack {
                    Spacer()
                    NavigationLink(destination: LabParameterEntryView(patient: patient, selectedTests: selectedTests)) {
                        Text("PROCEED TO TEST ENTRY")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(Color(red: 0.3, green: 0.8, blue: 0.8)) // Teal-ish
                            .cornerRadius(12)
                            .padding()
                    }
                    .background(
                        LinearGradient(gradient: Gradient(colors: [.black.opacity(0), .black]), startPoint: .top, endPoint: .bottom)
                            .padding(.top, -20)
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }

    private func toggleSelection(for test: String) {
        if selectedTests.contains(test) {
            selectedTests.removeAll(where: { $0 == test })
        } else {
            selectedTests.append(test)
        }
    }
}

#Preview {
    BioChemistryTestsView()
}

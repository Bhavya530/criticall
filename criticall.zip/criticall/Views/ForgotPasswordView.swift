import SwiftUI

struct ForgotPasswordView: View {
    @State private var userID = ""
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var showResetScreen = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // MARK: - Logo Section
                VStack(spacing: 12) {
                    Image("criticall_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .padding(.top, 40)
                    
                    Text("Forgot Password")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text("Enter your User ID to continue")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                }
                
                Spacer().frame(height: 50)
                
                // MARK: - Card
                VStack(alignment: .leading, spacing: 24) {
                    // User ID Field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("User ID")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(Color(white: 0.8))
                        
                        HStack(spacing: 12) {
                            Image(systemName: "person.fill")
                                .foregroundColor(Color(white: 0.5))
                                .font(.system(size: 18))
                            
                            TextField("Enter User ID", text: $userID)
                                .foregroundColor(.white)
                                .font(.system(size: 15))
#if os(iOS)
                                .textInputAutocapitalization(.never)
#endif
                        }
                        .padding(.vertical, 14)
                        .padding(.horizontal, 16)
                        .background(Color(white: 0.1))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color(white: 0.15), lineWidth: 1)
                        )
                    }
                    
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.system(size: 14))
                            .padding(.horizontal)
                    }
                    
                    // Verify Button
                    Button {
                        if userID.isEmpty {
                            errorMessage = "Please enter your User ID"
                            return
                        }
                        
                        isLoading = true
                        errorMessage = nil
                        
                        APIManager.shared.checkUserId(userId: userID) { success, error in
                            isLoading = false
                            if success {
                                showResetScreen = true
                            } else {
                                errorMessage = error ?? "Invalid ID"
                            }
                        }
                    } label: {
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text("Verify ID")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 15)
                                .background(Color(red: 45/255, green: 110/255, blue: 245/255))
                                .cornerRadius(14)
                        }
                    }
                    .disabled(isLoading || userID.isEmpty)
                    .padding(.top, 4)
                }
                .padding(24)
                .background(Color(white: 0.08))
                .cornerRadius(20)
                .padding(.horizontal, 20)
                
                Spacer()
            }
            
            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                        .padding()
                    }
                    Spacer()
                }
                Spacer()
            }
        }
        .navigationDestination(isPresented: $showResetScreen) {
            ResetPasswordScreen(userID: userID)
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }
}

struct ResetPasswordScreen: View {
    let userID: String
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var showNewPassword = false
    @State private var showConfirmPassword = false
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var successMessage: String?
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // MARK: - Logo Section
                VStack(spacing: 12) {
                    Text("Change Password")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                    
                    Text("Enter your new password for \(userID)")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                }
                
                Spacer().frame(height: 50)
                
                // MARK: - Card
                VStack(alignment: .leading, spacing: 24) {
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("New Password")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(Color(white: 0.8))
                        
                        HStack(spacing: 12) {
                            Image(systemName: "lock.fill")
                                .foregroundColor(Color(white: 0.5))
                                .font(.system(size: 18))
                            
                            if showNewPassword {
                                TextField("Enter new password", text: $newPassword)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled(true)
                            } else {
                                SecureField("Enter new password", text: $newPassword)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                            }
                            
                            Button(action: {
                                showNewPassword.toggle()
                            }) {
                                Image(systemName: showNewPassword ? "eye.fill" : "eye.slash.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .padding(.vertical, 8)
                            }
                        }
                        .padding(.vertical, 14)
                        .padding(.horizontal, 16)
                        .background(Color(white: 0.1))
                        .cornerRadius(12)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Confirm Password")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(Color(white: 0.8))
                        
                        HStack(spacing: 12) {
                            Image(systemName: "lock.fill")
                                .foregroundColor(Color(white: 0.5))
                                .font(.system(size: 18))
                            
                            if showConfirmPassword {
                                TextField("Confirm new password", text: $confirmPassword)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled(true)
                            } else {
                                SecureField("Confirm new password", text: $confirmPassword)
                                    .foregroundColor(.white)
                                    .font(.system(size: 15))
                            }
                            
                            Button(action: {
                                showConfirmPassword.toggle()
                            }) {
                                Image(systemName: showConfirmPassword ? "eye.fill" : "eye.slash.fill")
                                    .foregroundColor(Color(white: 0.5))
                                    .padding(.vertical, 8)
                            }
                        }
                        .padding(.vertical, 14)
                        .padding(.horizontal, 16)
                        .background(Color(white: 0.1))
                        .cornerRadius(12)
                    }
                    
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.system(size: 14))
                            .padding(.horizontal)
                    }
                    if let successMessage = successMessage {
                        Text(successMessage)
                            .foregroundColor(.green)
                            .font(.system(size: 14))
                            .padding(.horizontal)
                    }
                    
                    // Reset Button
                    Button {
                        if newPassword.isEmpty || newPassword != confirmPassword {
                            errorMessage = "Passwords do not match."
                            return
                        }
                        
                        isLoading = true
                        errorMessage = nil
                        
                        APIManager.shared.resetPasswordDirect(userId: userID, newPassword: ["password": newPassword]) { success, error in
                            isLoading = false
                            if success {
                                successMessage = "Password successfully changed!"
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    // Pop back to root
                                    dismiss()
                                }
                            } else {
                                errorMessage = error ?? "Failed to change password"
                            }
                        }
                    } label: {
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text("Change Password")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 15)
                                .background(Color(red: 45/255, green: 110/255, blue: 245/255))
                                .cornerRadius(14)
                        }
                    }
                    .disabled(isLoading || newPassword.isEmpty)
                    .padding(.top, 4)
                }
                .padding(24)
                .background(Color(white: 0.08))
                .cornerRadius(20)
                .padding(.horizontal, 20)
                
                Spacer()
            }
            
            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                        .padding()
                    }
                    Spacer()
                }
                Spacer()
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }
}

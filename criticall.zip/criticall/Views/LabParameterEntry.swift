import SwiftUI

struct LabParameterEntryView: View {
    @Environment(\.dismiss) var dismiss
    var patient: PatientModel?
    var selectedTests: [String]
    
    @State private var parameters: [String: String] = [:]
    @State private var isBiochemistryCollapsed = false
    @State private var isHematologyCollapsed = false
    @State private var isMicrobiologyCollapsed = false
    @State private var isCoagulationCollapsed = false
    @State private var isABGCollapsed = false
    @State private var isCytologyCollapsed = false
    @State private var isRadiologyCollapsed = false
    
    @State private var isSubmitting = false
    @State private var submissionError: String? = nil
    @State private var showSuccessToast = false
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    
                    Text("Lab Parameter Entry")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 15)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.black)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Patient Card
                        VStack(alignment: .leading, spacing: 15) {
                            HStack(spacing: 15) {
                                ZStack {
                                    Circle()
                                        .fill(Color.white.opacity(0.1))
                                        .frame(width: 50, height: 50)
                                    Image(systemName: "person.fill")
                                        .font(.system(size: 24))
                                        .foregroundColor(.gray)
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(patient?.full_name ?? "Patient")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                    Text("ID: \(patient?.patient_id ?? "N/A")")
                                        .font(.system(size: 14))
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Sections
                        VStack(alignment: .leading, spacing: 10) {
                            
                            // 1. HEMATOLOGY
                            if selectedTests.contains(where: { ["CBC", "ESR"].contains($0) }) {
                                SectionHeader(title: "Hematology", isCollapsed: $isHematologyCollapsed)
                                if !isHematologyCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("CBC") {
                                            ParameterInputCard(title: "Hemoglobin", normalRange: "Normal: 12-16 g/dL", placeholder: "Enter value", value: binding(for: "hemoglobin"), status: checkStatus(for: "hemoglobin"))
                                            ParameterInputCard(title: "Hematocrit", normalRange: "Normal: 36-46 %", placeholder: "Enter value", value: binding(for: "hematocrit"), status: checkStatus(for: "hematocrit"))
                                            ParameterInputCard(title: "Platelets", normalRange: "Normal: 150-450 x10^3/uL", placeholder: "Enter value", value: binding(for: "platelets"), status: checkStatus(for: "platelets"))
                                            ParameterInputCard(title: "WBC", normalRange: "Normal: 4.5-11 x10^3/uL", placeholder: "Enter value", value: binding(for: "wbc"), status: checkStatus(for: "wbc"))
                                        }
                                        if selectedTests.contains("ESR") {
                                            ParameterInputCard(title: "ESR", normalRange: "Normal: 0-30 mm/hr", placeholder: "Enter value", value: binding(for: "esr"), status: checkStatus(for: "esr"))
                                        }
                                    }
                                }
                            }
                            
                            // 2. BIOCHEMISTRY
                            if selectedTests.contains(where: { ["Electrolytes", "Basic Chemistry", "RFT", "LFT"].contains($0) }) {
                                SectionHeader(title: "Biochemistry", isCollapsed: $isBiochemistryCollapsed)
                                if !isBiochemistryCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("Electrolytes") {
                                            ParameterInputCard(title: "Sodium", normalRange: "135-145 mmol/L", placeholder: "Enter value", value: binding(for: "sodium"), status: checkStatus(for: "sodium"))
                                            ParameterInputCard(title: "Potassium", normalRange: "3.5-5.5 mmol/L", placeholder: "Enter value", value: binding(for: "potassium"), status: checkStatus(for: "potassium"))
                                            ParameterInputCard(title: "Calcium", normalRange: "8.5-10.5 mg/dL", placeholder: "Enter value", value: binding(for: "calcium"), status: checkStatus(for: "calcium"))
                                            ParameterInputCard(title: "Magnesium", normalRange: "1.7-2.2 mg/dL", placeholder: "Enter value", value: binding(for: "magnesium"), status: checkStatus(for: "magnesium"))
                                            ParameterInputCard(title: "Phosphorus", normalRange: "2.5-4.5 mg/dL", placeholder: "Enter value", value: binding(for: "phosphorus"), status: checkStatus(for: "phosphorus"))
                                            ParameterInputCard(title: "Chloride", normalRange: "98-107 mmol/L", placeholder: "Enter value", value: binding(for: "chloride"), status: checkStatus(for: "chloride"))
                                        }
                                        if selectedTests.contains("Basic Chemistry") || selectedTests.contains("RFT") {
                                            ParameterInputCard(title: "Glucose", normalRange: "70-140 mg/dL", placeholder: "Enter value", value: binding(for: "glucose"), status: checkStatus(for: "glucose"))
                                            ParameterInputCard(title: "Lactate", normalRange: "<2.0 mmol/L", placeholder: "Enter value", value: binding(for: "lactate"), status: checkStatus(for: "lactate"))
                                            ParameterInputCard(title: "Bicarbonate", normalRange: "22-28 mmol/L", placeholder: "Enter value", value: binding(for: "bicarbonate"), status: checkStatus(for: "bicarbonate"))
                                            ParameterInputCard(title: "Urea", normalRange: "7-20 mg/dL", placeholder: "Enter value", value: binding(for: "urea"), status: checkStatus(for: "urea"))
                                            ParameterInputCard(title: "Creatinine", normalRange: "0.6-1.2 mg/dL", placeholder: "Enter value", value: binding(for: "creatinine"), status: checkStatus(for: "creatinine"))
                                        }
                                    }
                                }
                            }

                            // 3. MICROBIOLOGY
                            if selectedTests.contains(where: { ["Blood Culture", "CSF Culture", "TB Smear"].contains($0) }) {
                                SectionHeader(title: "Microbiology", isCollapsed: $isMicrobiologyCollapsed)
                                if !isMicrobiologyCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("Blood Culture") {
                                            ParameterInputCard(title: "Blood Culture", normalRange: "Normal: Negative", placeholder: "Enter result", value: binding(for: "blood_culture"), status: checkStatus(for: "blood_culture"))
                                        }
                                        if selectedTests.contains("CSF Culture") {
                                            ParameterInputCard(title: "CSF Culture / Gram Stain", normalRange: "Normal: Negative", placeholder: "Enter result", value: binding(for: "csf_culture"), status: checkStatus(for: "csf_culture"))
                                        }
                                        if selectedTests.contains("TB Smear") {
                                            ParameterInputCard(title: "TB Smear / Test", normalRange: "Normal: Negative", placeholder: "Enter result", value: binding(for: "tb_test"), status: checkStatus(for: "tb_test"))
                                        }
                                    }
                                }
                            }

                            // 4. COAGULATION
                            if selectedTests.contains(where: { ["PT", "INR", "APTT"].contains($0) }) {
                                SectionHeader(title: "Coagulation", isCollapsed: $isCoagulationCollapsed)
                                if !isCoagulationCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("INR") {
                                            ParameterInputCard(title: "INR", normalRange: "Normal: 0.8-1.1", placeholder: "Enter value", value: binding(for: "inr"), status: checkStatus(for: "inr"))
                                        }
                                        if selectedTests.contains("PT") {
                                            ParameterInputCard(title: "PT", normalRange: "", placeholder: "Enter value", value: binding(for: "pt"))
                                        }
                                        if selectedTests.contains("APTT") {
                                            ParameterInputCard(title: "APTT", normalRange: "", placeholder: "Enter value (seconds)", value: binding(for: "aptt"))
                                        }
                                    }
                                }
                            }

                            // 5. ABG
                            if selectedTests.contains(where: { ["pH", "pCO2", "pO2"].contains($0) }) {
                                SectionHeader(title: "ABG", isCollapsed: $isABGCollapsed)
                                if !isABGCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("pH") {
                                            ParameterInputCard(title: "pH", normalRange: "Normal: 7.35–7.45", placeholder: "Enter value", value: binding(for: "abg_ph"), status: checkStatus(for: "abg_ph"))
                                        }
                                        if selectedTests.contains("pCO2") {
                                            ParameterInputCard(title: "pCO2", normalRange: "Normal: 35-45 mmHg", placeholder: "Enter value (mmHg)", value: binding(for: "abg_pco2"), status: checkStatus(for: "abg_pco2"))
                                        }
                                        if selectedTests.contains("pO2") {
                                            ParameterInputCard(title: "pO2", normalRange: "Normal: 80-100 mmHg", placeholder: "Enter value (mmHg)", value: binding(for: "abg_po2"), status: checkStatus(for: "abg_po2"))
                                        }
                                    }
                                }
                            }

                            // 6. CYTOLOGY
                            if selectedTests.contains(where: { ["Malignant Cells", "Pathogens on Smear"].contains($0) }) {
                                SectionHeader(title: "Cytology", isCollapsed: $isCytologyCollapsed)
                                if !isCytologyCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("Malignant Cells") {
                                            ParameterInputCard(title: "Malignant Cells", normalRange: "Normal: Absent", placeholder: "Enter result", value: binding(for: "malignant_cells"), status: checkStatus(for: "malignant_cells"))
                                        }
                                        if selectedTests.contains("Pathogens on Smear") {
                                            ParameterInputCard(title: "Pathogens on Smear", normalRange: "Normal: Absent", placeholder: "Enter result", value: binding(for: "pathogens_on_smear"), status: checkStatus(for: "pathogens_on_smear"))
                                        }
                                    }
                                }
                            }

                            // 7. RADIOLOGY
                            if selectedTests.contains(where: { ["Tension Pneumothorax", "Pulmonary Embolism", "Aortic Dissection", "New Pneumoperitoneum"].contains($0) }) {
                                SectionHeader(title: "Radiology", isCollapsed: $isRadiologyCollapsed)
                                if !isRadiologyCollapsed {
                                    VStack(alignment: .leading, spacing: 15) {
                                        if selectedTests.contains("Tension Pneumothorax") {
                                            ParameterInputCard(title: "Tension Pneumothorax", normalRange: "Normal: No", placeholder: "Enter finding", value: binding(for: "tension_pneumothorax"), status: checkStatus(for: "tension_pneumothorax"))
                                        }
                                        if selectedTests.contains("Pulmonary Embolism") {
                                            ParameterInputCard(title: "Pulmonary Embolism", normalRange: "Normal: No", placeholder: "Enter finding", value: binding(for: "pulmonary_embolism"), status: checkStatus(for: "pulmonary_embolism"))
                                        }
                                        if selectedTests.contains("Aortic Dissection") {
                                            ParameterInputCard(title: "Aortic Dissection", normalRange: "Normal: No", placeholder: "Enter finding", value: binding(for: "aortic_dissection"), status: checkStatus(for: "aortic_dissection"))
                                        }
                                        if selectedTests.contains("New Pneumoperitoneum") {
                                            ParameterInputCard(title: "New Pneumoperitoneum", normalRange: "Normal: No", placeholder: "Enter finding", value: binding(for: "new_pneumoperitoneum"), status: checkStatus(for: "new_pneumoperitoneum"))
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Submit Button
                        Button {
                            submitReport()
                        } label: {
                            if isSubmitting {
                                ProgressView().tint(.white)
                            } else {
                                Text("SUBMIT LAB REPORT")
                                    .font(.system(size: 18, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 18)
                                    .background(Color(red: 0.2, green: 0.7, blue: 0.4))
                                    .cornerRadius(12)
                            }
                        }
                        .disabled(isSubmitting || parameters.isEmpty)
                        .padding(.horizontal)
                        .padding(.top, 10)
                        .padding(.bottom, 30)
                        
                        if let error = submissionError {
                            Text(error)
                                .foregroundColor(.red)
                                .font(.caption)
                                .padding(.horizontal)
                                .padding(.bottom, 20)
                        }
                    }
                }
            }
            
            if showSuccessToast {
                VStack {
                    Spacer()
                    HStack(spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(.green)
                        
                        Text("Test results saved successfully")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Color.white)
                    .cornerRadius(25)
                    .shadow(radius: 10)
                    .padding(.bottom, 30)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .zIndex(1)
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.dark)
    }
    
    private func binding(for key: String) -> Binding<String> {
        Binding(get: { parameters[key] ?? "" }, set: { parameters[key] = $0 })
    }

    private func submitReport() {
        guard let patient = patient else { return }
        isSubmitting = true
        submissionError = nil
        
        APIManager.shared.submitLabReport(
            patientId: patient.patient_id,
            doctorId: patient.doctor_user_id ?? "DR001",
            labUserId: APIManager.shared.currentUser?.userId ?? "LAB001",
            category: selectedTests.first ?? "General",
            payload: parameters
        ) { success, error in
            if success {
                checkAndPostCriticalAlerts()
                withAnimation {
                    showSuccessToast = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    isSubmitting = false
                    dismiss()
                }
            } else {
                isSubmitting = false
                submissionError = error ?? "Failed to submit report"
            }
        }
    }

    private func checkAndPostCriticalAlerts() {
        guard let patient = patient else { return }
        let doctorId = patient.doctor_user_id ?? "DR001"
        
        for (key, valStr) in parameters {
            let status = checkStatus(for: key)
            if status.isCritical {
                APIManager.shared.postCriticalNotification(
                    doctorId: doctorId,
                    patientId: patient.patient_id,
                    patientName: patient.full_name,
                    alertType: "Critical \(key.capitalized)",
                    value: valStr,
                    normalRange: "Critical Threshold Crossed"
                ) { _, _ in }
            }
        }
    }

    private func checkStatus(for key: String) -> ParameterInputCard.ParameterStatus {
        guard let valStr = parameters[key] else { return .normal }
        
        let lowerVal = valStr.lowercased()
        let isPositive = lowerVal.contains("positive") || lowerVal.contains("detected") || lowerVal.contains("malignant")
        let isUrgent = lowerVal.contains("pneumothorax") || lowerVal.contains("embolism") || lowerVal.contains("dissection")
        
        let nonNumeric = ["blood_culture", "csf_culture", "tb_test", "malignant_cells", "pathogens_on_smear", "tension_pneumothorax", "pulmonary_embolism", "aortic_dissection", "new_pneumoperitoneum"]
        if nonNumeric.contains(key) {
            return (isPositive || isUrgent) ? .criticalHigh("Positive Finding") : .normal
        }
        
        guard let val = Double(valStr) else { return .normal }
        
        switch key {
        case "hemoglobin":
            if val < 7.0 { return .criticalLow("7.0") }
            if val > 20.0 { return .criticalHigh("20.0") }
            if val < 12.0 || val > 16.0 { return .outside }
        case "sodium":
            if val < 120.0 { return .criticalLow("120.0") }
            if val > 160.0 { return .criticalHigh("160.0") }
            if val < 135.0 || val > 145.0 { return .outside }
        case "potassium":
            if val < 3.5 { return .criticalLow("3.5") }
            if val > 5.5 { return .criticalHigh("5.5") }
        case "glucose":
            if val < 40.0 { return .criticalLow("40.0") }
            if val > 450.0 { return .criticalHigh("450.0") }
        case "calcium":
            if val < 7.0 { return .criticalLow("7.0") }
            if val > 12.0 { return .criticalHigh("12.0") }
        case "magnesium":
            if val < 1.0 { return .criticalLow("1.0") }
            if val > 5.0 { return .criticalHigh("5.0") }
        case "lactate":
            if val > 5.0 { return .criticalHigh("5.0") }
        case "bicarbonate":
            if val < 10.0 { return .criticalLow("10.0") }
            if val > 36.0 { return .criticalHigh("36.0") }
        case "urea": if val > 100.0 { return .criticalHigh("100") }
        case "creatinine": if val > 10.0 { return .criticalHigh("10") }
        case "wbc":
            if val < 2.0 { return .criticalLow("2.0") }
            if val > 40.0 { return .criticalHigh("40.0") }
        case "platelets":
            if val < 20.0 { return .criticalLow("20.0") }
            if val > 1000.0 { return .criticalHigh("1000.0") }
        case "inr": if val > 6.0 { return .criticalHigh("6.0") }
        default: break
        }
        return .normal
    }
}

struct ParameterInputCard: View {
    var title: String
    var normalRange: String
    var placeholder: String
    @Binding var value: String
    var status: ParameterStatus = .normal
    
    enum ParameterStatus: Equatable {
        case normal, outside, criticalHigh(String), criticalLow(String)
        var isCritical: Bool {
            switch self {
            case .criticalHigh, .criticalLow: return true
            default: return false
            }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title).font(.system(size: 14, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                if !normalRange.isEmpty {
                    Text("— \(normalRange)").font(.system(size: 12)).foregroundColor(.gray)
                }
                Spacer()
                if status.isCritical {
                    Image(systemName: "exclamationmark.octagon.fill").foregroundColor(.red)
                }
            }
            TextField(placeholder, text: $value)
                .padding()
                .background(Color.white.opacity(0.05))
                .cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(status.isCritical ? Color.red : Color.clear, lineWidth: 1))
                .foregroundColor(.white)
        }
        .padding(.horizontal)
    }
}

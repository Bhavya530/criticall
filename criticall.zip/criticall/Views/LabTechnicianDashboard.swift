import SwiftUI

struct LabDashboardView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedTab = 0
    @ObservedObject private var api = APIManager.shared
    
    var body: some View {
            ZStack {
                Color(red: 10/255, green: 10/255, blue: 10/255)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    if selectedTab == 0 {
                        DashboardHomeView()
                    } else if selectedTab == 1 {
                        LabQueueView(selectedTab: $selectedTab)
                    } else {
                        ProfileView(selectedTab: $selectedTab, onLogout: { APIManager.shared.logout() })
                    }
                    
                    // Navigation Bar
                HStack(spacing: 0) {
                    TabItem(icon: "house.fill", label: "Home", isActive: selectedTab == 0) {
                        selectedTab = 0
                    }
                    .frame(maxWidth: .infinity)
                    
                    TabItem(icon: "doc.text.fill", label: "Queue", isActive: selectedTab == 1) {
                        selectedTab = 1
                    }
                    .frame(maxWidth: .infinity)
                    
                    TabItem(icon: "person.fill", label: "Profile", isActive: selectedTab == 2) {
                        selectedTab = 2
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.vertical, 8)
                .background(Color.white.opacity(0.05))
                .cornerRadius(25)
                .padding(.horizontal, 20)
                .padding(.bottom, 10)
                }
            }
            .navigationBarHidden(true)
            .onChange(of: api.currentUser == nil) { oldVal, isLoggedOut in
                if isLoggedOut {
                    dismiss()
                }
            }
    }
}

struct DashboardHomeView: View {
    @StateObject private var viewModel = LabQueueViewModel()
    @State private var searchText = ""
    @State private var goToAlerts = false
    @ObservedObject private var api = APIManager.shared
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color(red: 26/255, green: 188/255, blue: 156/255))
                        .frame(width: 45, height: 45)
                    Text(String(APIManager.shared.currentUser?.name.prefix(1) ?? "L"))
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("Welcome, \(APIManager.shared.currentUser?.name ?? "Technician")")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    
                    let dept = APIManager.shared.currentUser?.department ?? "Microbiology"
                    Text("\(dept) • \(Date().formatted(date: .abbreviated, time: .omitted))")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                Button(action: {
                    goToAlerts = true
                }) {
                    ZStack {
                        Image(systemName: "bell.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.white)
                        
                        Circle()
                            .fill(Color.orange)
                            .frame(width: 8, height: 8)
                            .offset(x: 8, y: -8)
                    }
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 12) {
                    // Summary Rows
                    VStack(spacing: 12) {
                        SummaryRow(title: "Patients Assigned", value: "\(viewModel.queuePatients.count)", icon: "person.2.fill")
                        SummaryRow(title: "Reports Submitted Today", value: "0", icon: "doc.text.fill")
                        SummaryRow(title: "Pending Reports", value: "\(viewModel.queuePatients.count)", icon: "circle.fill")
                    }
                    .padding(.top, 20)
                    
                    // Search Bar
                    HStack {
                        TextField("Search patients or tests...", text: $searchText)
                            .foregroundColor(.white)
                            .font(.system(size: 16))
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 14)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .padding(.top, 10)
                    
                    HStack {
                        Text("Patients")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                        Spacer()
                        Text("\(viewModel.queuePatients.count) patients")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(Color.red.opacity(0.7))
                            .cornerRadius(10)
                    }
                    .padding(.top, 15)
                    
                    if viewModel.isLoading {
                        ProgressView("Loading patients...")
                            .foregroundColor(.white)
                            .padding(.top, 20)
                    } else if let error = viewModel.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .padding(.top, 20)
                    } else if viewModel.queuePatients.isEmpty {
                        Text("No patients queued.")
                            .foregroundColor(.gray)
                            .padding(.top, 20)
                    } else {
                        let filtered = viewModel.queuePatients.filter {
                            searchText.isEmpty || $0.full_name.localizedCaseInsensitiveContains(searchText) || $0.id.localizedCaseInsensitiveContains(searchText)
                        }
                        
                        ForEach(filtered) { patient in
                            NavigationLink(destination: LabCategoryView(patient: patient)) {
                                PatientCardView(patient: patient)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
            }
        }
        .navigationDestination(isPresented: $goToAlerts) {
            CriticalAlertsView()
        }
        .onAppear {
            viewModel.fetchQueuedPatients()
        }
        .onChange(of: api.currentUser == nil) { oldVal, isLoggedOut in
            if isLoggedOut {
                goToAlerts = false
            }
        }
    }
}

struct SummaryRow: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        HStack {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .foregroundColor(.white)
                    .font(.system(size: 18))
            }
            
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
                .padding(.leading, 8)
            
            Spacer()
            
            Text(value)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.white)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 20)
        .background(Color.white.opacity(0.05))
        .cornerRadius(20)
    }
}

struct PatientCardView: View {
    let patient: PatientModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 16) {
                // Profile Image Placeholder
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 80, height: 80)
                    .overlay(
                        Image(systemName: "person.fill")
                            .resizable()
                            .scaledToFit()
                            .padding(20)
                            .foregroundColor(.gray)
                    )
                
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(patient.full_name)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                        Spacer()
                        Text("\(patient.age ?? 0)y, \(patient.gender ?? "")")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    
                    Text("ID: \(patient.patient_id)")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    
                    Spacer(minLength: 5)
                    
                    Divider().background(Color.white.opacity(0.1))
                    
                    HStack(spacing: 8) {
                        Text("Tests Reported:")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.gray)
                        
                        let tests = patient.tests_ordered?.components(separatedBy: ",") ?? []
                        if tests.isEmpty {
                            ReportChip(text: "None")
                        } else {
                            ForEach(tests.prefix(2), id: \.self) { test in
                                let trimmed = test.trimmingCharacters(in: .whitespaces)
                                if !trimmed.isEmpty {
                                    ReportChip(text: trimmed)
                                }
                            }
                            if tests.count > 2 {
                                Text("+\(tests.count - 2)")
                                    .font(.system(size: 11))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(.top, 4)
                }
            }
        }
        .padding(16)
        .background(Color.white.opacity(0.03))
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.white.opacity(0.05), lineWidth: 1)
        )
    }
}

struct ReportChip: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(size: 11))
            .foregroundColor(.gray)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.white.opacity(0.08))
            .cornerRadius(15)
    }
}

struct TabItem: View {
    let icon: String
    let label: String
    let isActive: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(isActive ? Color(red: 46/255, green: 204/255, blue: 113/255) : .gray)
                
                if isActive {
                    Circle()
                        .fill(Color(red: 46/255, green: 204/255, blue: 113/255))
                        .frame(width: 4, height: 4)
                } else {
                    Circle()
                        .fill(Color.clear)
                        .frame(width: 4, height: 4)
                }
            }
            .frame(width: 100, height: 48) // Equal distribution frame
            .background(isActive ? Color.white.opacity(0.08) : Color.clear)
            .cornerRadius(12)
        }
    }
}

struct LabDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        LabDashboardView()
            .preferredColorScheme(.dark)
    }
}

//
//  LabTechnicianDashboard.swift
//  criticall
//
//  Created by Hemanth Kumar on 28/02/26.
//


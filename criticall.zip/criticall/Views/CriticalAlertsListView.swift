import SwiftUI

// Shared models and data are defined in CriticalAlerts.swift

struct CriticalAlertsListView: View {
    @StateObject private var viewModel = CriticalAlertsViewModel()
    @State private var selectedAlert: CriticalNotificationModel?

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    Text("Critical Alerts")
                        .foregroundColor(.white)
                        .font(.title)
                        .bold()
                    Spacer()
                    Text("\(viewModel.activeCount) Active")
                        .font(.subheadline)
                        .foregroundColor(.red)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color.red.opacity(0.2))
                        .cornerRadius(15)
                }
                .padding(.horizontal)
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.yellow)
                    Text("\(viewModel.activeCount) critical alerts require immediate attention")
                        .foregroundColor(.white)
                        .font(.callout)
                    Spacer()
                }
                .padding()
                .background(Color.red.opacity(0.3))
                .cornerRadius(12)
                .padding(.horizontal)

                if viewModel.isLoading {
                    ProgressView()
                } else {
                    ForEach(viewModel.activeAlerts) { alert in
                        AlertListCard(alert: alert, onRecommendMedication: {
                            selectedAlert = alert
                        })
                        .padding(.horizontal)
                    }

                    ForEach(viewModel.resolvedAlerts) { alert in
                        AlertListCard(alert: alert, onRecommendMedication: {
                            selectedAlert = alert
                        })
                        .padding(.horizontal)
                    }
                }

                Spacer(minLength: 20)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical)
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .sheet(item: $selectedAlert) { alert in
            RecommendMedicationSheet(alert: alert) {
                selectedAlert = nil
            }
            .presentationDetents([.medium, .large])
        }
        .onAppear {
            viewModel.fetchAlerts()
        }
    }
}

// AlertListCard is defined in CriticalAlerts.swift

#Preview {
    CriticalAlertsListView()
}

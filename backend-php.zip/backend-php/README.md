# CritiCall PHP Backend

## Run locally

1. Create MySQL database and tables:

```sql
SOURCE schema.sql;
```

2. Copy `.env.example` to `.env` and set DB credentials.

3. Start PHP server:

```bash
php -S 0.0.0.0:8080 -t public public/index.php
```

## API base

`http://localhost:8080/api`

## Core routes

- `POST /api/auth/login`
- `POST /api/auth/signup-labtech`
- `GET|PUT /api/users/{doctors|labtechs}/{userId}`
- `POST /api/users/{doctors|labtechs}/{userId}/change-password`
- `POST /api/users/{doctors|labtechs}/{userId}/notification-preferences`
- `GET|POST /api/patients/{doctorId}`
- `GET|PUT /api/patients/{doctorId}/{patientId}`
- `GET|POST /api/critical-notifications/{doctorId}`
- `PUT /api/critical-notifications/{doctorId}/{notificationId}/resolve`
- `GET /api/predicted-alerts/{doctorId}`
- `PUT /api/predicted-alerts/{doctorId}/{patientId}`
- `POST /api/test-results`
- `GET|POST /api/lab-tech-notifications/{labUserId}`

## Notes

- Passwords are stored using `password_hash`.
- Token table is implemented for bearer-token migration, though endpoints currently accept direct calls for cutover speed.
- This backend is designed as the primary backend for Android app data paths.

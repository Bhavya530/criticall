import SwiftUI

struct NotificationPreferencesView: View {
    @Environment(\.dismiss) var dismiss
    @State private var criticalAlerts = true
    @State private var labReports = true
    @State private var patientUpdates = false
    @State private var systemNotifications = true
    var body: some View {
        ZStack {
            Color(red: 13/255, green: 17/255, blue: 23/255)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Header with Back Button
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    .padding(.leading, 20)
                    
                    Spacer()
                }
                .padding(.top, 20)
                
                Text("Notification Settings")
                    .font(.system(size: 32, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 20)
                    .padding(.bottom, 30)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        
                        Text("COMMUNICATION CHANNELS")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.gray)
                            .padding(.leading, 4)
                            .padding(.bottom, 8)
                        
                        VStack(spacing: 0) {
                            PreferenceToggleRow(
                                icon: "bell.badge.fill",
                                title: "Critical Alerts",
                                description: "Immediate notifications for life-threatening patient conditions",
                                iconColor: .red,
                                isOn: $criticalAlerts
                            )
                            Divider().background(Color.white.opacity(0.1))
                            PreferenceToggleRow(
                                icon: "flask.fill",
                                title: "Lab Reports",
                                description: "Get notified when new lab test results are available",
                                iconColor: .teal,
                                isOn: $labReports
                            )
                            Divider().background(Color.white.opacity(0.1))
                            PreferenceToggleRow(
                                icon: "person.text.rectangle.fill",
                                title: "Patient Updates",
                                description: "Stay updated on patient admissions and transfers",
                                iconColor: .blue,
                                isOn: $patientUpdates
                            )
                            Divider().background(Color.white.opacity(0.1))
                            PreferenceToggleRow(
                                icon: "gearshape.fill",
                                title: "System Notifications",
                                description: "Important announcements and application updates",
                                iconColor: .gray,
                                isOn: $systemNotifications
                            )
                        }
                        .background(Color(red: 30/255, green: 35/255, blue: 40/255))
                        .cornerRadius(16)
                        .shadow(color: Color.black.opacity(0.5), radius: 8, x: 0, y: 2)
                        
                        Text("Preferences are synced across all your devices.")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 20)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 40)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct PreferenceToggleRow: View {
    let icon: String
    let title: String
    let description: String
    let iconColor: Color
    @Binding var isOn: Bool
    
    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(.white)
                .frame(width: 40, height: 40)
                .background(iconColor.opacity(0.2))
                .cornerRadius(10)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(description)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .lineLimit(2)
            }
            
            Spacer()
            
            Toggle("", isOn: $isOn)
                .toggleStyle(SwitchToggleStyle(tint: .teal))
                .labelsHidden()
        }
        .padding(.vertical, 16)
        .padding(.horizontal, 16)
    }
}

#Preview {
    NotificationPreferencesView()
}

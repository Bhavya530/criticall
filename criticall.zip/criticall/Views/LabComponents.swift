import SwiftUI

struct TestCategoryRow: View {
    var title: String
    var subtitle: String
    var tags: [String]
    var isSelected: Bool
    var onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title)
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                        Text(subtitle)
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    Image(systemName: isSelected ? "largecircle.fill.circle" : "circle")
                        .foregroundColor(isSelected ? .white : .gray.opacity(0.5))
                        .font(.system(size: 24))
                }

                HStack(spacing: 8) {
                    ForEach(tags, id: \.self) { tag in
                        Text(tag)
                            .font(.system(size: 13))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.white.opacity(0.1))
                            .foregroundColor(.white.opacity(0.6))
                            .cornerRadius(15)
                    }
                }
            }
            .padding()
            .background(Color.white.opacity(0.05))
            .cornerRadius(16)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(isSelected ? Color.white.opacity(0.2) : Color.clear, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct SectionHeader: View {
    var title: String
    @Binding var isCollapsed: Bool
    
    var body: some View {
        Button(action: { withAnimation { isCollapsed.toggle() } }) {
            HStack {
                Image(systemName: isCollapsed ? "chevron.right" : "chevron.down")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                Text(title)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
        }
        .buttonStyle(.plain)
    }
}

struct CommonAlertView: View {
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(Color(red: 0.9, green: 0.7, blue: 0.1))
                .font(.system(size: 24))
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Critical Alert System")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color(red: 0.9, green: 0.7, blue: 0.1))
                Text("Tests marked with alert icons will automatically trigger notifications for positive findings or critical values.")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .lineSpacing(4)
            }
        }
        .padding()
        .background(Color(red: 0.2, green: 0.2, blue: 0.05))
        .cornerRadius(16)
    }
}

